"""Minimal Bruker TopSpin reader/writer for 1D spectra (fid, acqus, pdata/N/1r, procs).

Reading: parameters are parsed from the JCAMP-style acqus/procs files; 1r is int32 scaled by 2**NC_proc;
the ppm axis runs from OFFSET (first point) downwards over SW_p/SF ppm.
Writing: produces the same files, so synthetic spectra open in TopSpin-like tools and in the MRI Data Explorer.
"""
from __future__ import annotations
import os, re
import numpy as np


def read_params(path):
    p, key = {}, None
    txt = open(path, encoding="latin1").read()
    for line in txt.splitlines():
        m = re.match(r"##\$?([^=]+)=\s*(.*)", line)
        if m:
            key, val = m.group(1).strip(), m.group(2).strip()
            if val.startswith("("):
                p[key] = []
                continue
            p[key] = val.strip("<>")
            key = None
        elif key and isinstance(p.get(key), list) and not line.startswith("$$"):
            p[key] += line.split()
    return p


def num(p, k, default=None):
    try:
        return float(p[k])
    except (KeyError, ValueError, TypeError):
        return default


def read_1r(expdir, procno=1):
    pdir = os.path.join(expdir, "pdata", str(procno))
    pr = read_params(os.path.join(pdir, "procs"))
    dt = "<i4" if int(num(pr, "BYTORDP", 0)) == 0 else ">i4"
    y = np.fromfile(os.path.join(pdir, "1r"), dtype=dt).astype(float) * 2.0 ** num(pr, "NC_proc", 0)
    si = len(y)
    off, sw, sf = num(pr, "OFFSET"), num(pr, "SW_p"), num(pr, "SF")
    ppm = off - np.arange(si) * (sw / sf) / si
    return ppm, y, pr


def read_fid(expdir):
    ac = read_params(os.path.join(expdir, "acqus"))
    dt = "<i4" if int(num(ac, "BYTORDA", 0)) == 0 else ">i4"
    if int(num(ac, "DTYPA", 0)) == 2:
        dt = dt.replace("i4", "f8")
    raw = np.fromfile(os.path.join(expdir, "fid"), dtype=dt).astype(float) * 2.0 ** num(ac, "NC", 0)
    return raw[0::2] + 1j * raw[1::2], ac


def _jcamp(title, params):
    out = [f"##TITLE= {title}", "##JCAMPDX= 5.0", "##DATATYPE= Parameter Values", "##ORIGIN= BHDT-Na23 synthetic generator",
           "##OWNER= synthetic"]
    for k, v in params.items():
        if isinstance(v, str):
            out.append(f"##${k}= <{v}>")
        else:
            out.append(f"##${k}= {v}")
    out.append("##END=")
    return "\n".join(out) + "\n"


def write_experiment(expdir, fid, spec_real, acq, proc, title="synthetic", pulseprogram="zg_se1.gep"):
    """fid: complex array; spec_real: processed real spectrum (SI points). acq/proc: parameter dicts."""
    os.makedirs(os.path.join(expdir, "pdata", "1"), exist_ok=True)
    sc = np.max(np.abs(np.r_[fid.real, fid.imag])) or 1.0
    nc_a = int(np.floor(np.log2(sc / 2.0 ** 29)))          # may be negative: value = int * 2**NC
    fid_i = np.empty(2 * len(fid), dtype="<i4")
    fid_i[0::2] = np.round(fid.real / 2.0 ** nc_a)
    fid_i[1::2] = np.round(fid.imag / 2.0 ** nc_a)
    fid_i.tofile(os.path.join(expdir, "fid"))
    a = dict(acq); a.update(BYTORDA=0, DTYPA=0, NC=nc_a, TD=2 * len(fid), PULPROG=pulseprogram)
    open(os.path.join(expdir, "acqus"), "w").write(_jcamp("Parameter file, synthetic acqus", a))
    open(os.path.join(expdir, "pulseprogram"), "w").write(f";{pulseprogram} (synthetic placeholder: name copied from the Bray acquisition)\n")
    m = np.max(np.abs(spec_real)) or 1.0
    nc = int(np.floor(np.log2(m / 2.0 ** 29)))
    y = np.round(spec_real / 2.0 ** nc).astype("<i4")
    y.tofile(os.path.join(expdir, "pdata", "1", "1r"))
    pr = dict(proc); pr.update(BYTORDP=0, DTYPP=0, NC_proc=nc, SI=len(spec_real))
    open(os.path.join(expdir, "pdata", "1", "procs"), "w").write(_jcamp("Parameter file, synthetic procs", pr))
    open(os.path.join(expdir, "pdata", "1", "title"), "w").write(title + "\n")
