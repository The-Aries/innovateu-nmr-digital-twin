"""Step 2 — process and fit every spectrum, then calibrate detection and uncertainty on the calibration sets.

python scripts/fit_spectra.py [dataset_root]

Reads only nmr/spectra and metadata (never ground_truth/). Writes:
  nmr/fitted_peaks.csv, nmr/spectra_csv/*.csv, nmr/acquisition_parameters.csv,
  nmr/noise_calibration.csv, config/detection_calibration.json
"""
from __future__ import annotations
import os, sys, json
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bruker as B, nmrproc as N, fitting as F, simulate as S

FIT_VERSION = "fit_spectra 1.0"
CAL_LEVELS = (300, 600, 900)


def process_exp(expdir, version="1.0"):
    fid, ac = B.read_fid(expdir)
    acq = dict(SW_h=B.num(ac, "SW_h"), SF=B.num(ac, "BF1"), OFFSET_ppm=S.ACQ["OFFSET_ppm"])
    ppm, y, info = N.process(fid, acq, version)
    ns = F.noise_sd(ppm, y)
    met = F.fit_metal(ppm, y, ns)
    ref = F.fit_reference_td(fid, acq["SW_h"], acq["SF"], acq["OFFSET_ppm"])
    return ppm, y, ns, met, ref, ac, info


def main(root, version="1.0"):
    idx = pd.read_csv(os.path.join(root, "metadata", "spectra_index.csv"))
    os.makedirs(os.path.join(root, "nmr", "spectra_csv"), exist_ok=True)
    rows, acqrows = [], []
    for r in idx.itertuples():
        d = os.path.join(root, r.path)
        ppm, y, ns, met, ref, ac, info = process_exp(d, version)
        stage = "eoc" if r.stage == "end_of_charge" else "pd"
        csvp = f"nmr/spectra_csv/{r.replay}_{int(r.cycle_n):02d}_{stage}.csv"
        if not r.replay.startswith("CAL"):
            pd.DataFrame({"ppm": np.round(ppm, 4), "intensity_au": np.round(y, 5)}).to_csv(os.path.join(root, csvp), index=False)
        else:
            csvp = ""
        row = dict(replay=r.replay, cycle_n=r.cycle_n, stage=r.stage, expno=r.expno, source_object=r.path + "/fid", spectrum_csv=csvp,
                   noise_sd=ns, phase_rad=info["phase_rad"], processing_version=version, fit_version=FIT_VERSION)
        for k, v in met.items():
            row["metal_" + k] = v
        for k, v in ref.items():
            row[k] = v
        rows.append(row)
        acqrows.append(dict(replay=r.replay, cycle_n=r.cycle_n, stage=r.stage, expno=r.expno, nucleus=ac.get("NUC1"),
                            spectrometer_frequency_MHz=B.num(ac, "BF1"), carrier_frequency_MHz=B.num(ac, "SFO1"), spectral_width_Hz=B.num(ac, "SW_h"),
                            number_of_points=int(B.num(ac, "TD")), number_of_scans=int(B.num(ac, "NS")), relaxation_delay_s=B.num(ac, "D1"),
                            acquisition_time_s=round(B.num(ac, "TD") / 2 / B.num(ac, "SW_h"), 6), pulse_program=ac.get("PULPROG"),
                            probe=ac.get("PROBHD"), field_strength_T=round(B.num(ac, "BF1") / 11.262, 3), origin="SIMULATED (parameters copied from Bray Figure 5)"))
    fp = pd.DataFrame(rows)

    # ---------------- calibration: uncertainty inflation, detection cutoffs, upper-limit rule
    cal0 = fp[fp.replay == "CAL0"]
    snr0 = cal0.metal_snr.fillna(0).values
    unc_cut = float(max(3.0, np.quantile(snr0, 0.95)))
    det_cut = float(max(5.0, np.quantile(snr0, 0.995)))
    levels, ncal = [], []
    for lvl in CAL_LEVELS:
        g = fp[fp.replay == f"CALW{lvl}"]
        p_unc = float(np.mean(g.metal_snr >= unc_cut))
        p_det = float(np.mean(g.metal_snr >= det_cut))
        k_u = float(np.std(g.metal_area) / np.median(g.metal_u_area))
        levels.append((lvl, p_unc, p_det, k_u, float(np.mean(g.metal_area)), float(np.std(g.metal_area))))
        ncal.append(dict(set=f"CALW{lvl}", injected_area_au=lvl, n=len(g), fraction_snr_ge_uncertain_cut=p_unc, fraction_snr_ge_detect_cut=p_det,
                         mean_fitted_area=float(np.mean(g.metal_area)), sd_fitted_area=float(np.std(g.metal_area)),
                         median_reported_u_area=float(np.median(g.metal_u_area)), uncertainty_inflation=k_u))
    ncal.insert(0, dict(set="CAL0", injected_area_au=0, n=len(cal0), fraction_snr_ge_uncertain_cut=float(np.mean(snr0 >= unc_cut)),
                        fraction_snr_ge_detect_cut=float(np.mean(snr0 >= det_cut)), mean_fitted_area=float(cal0.metal_area.mean()),
                        sd_fitted_area=float(cal0.metal_area.std()), median_reported_u_area=float(cal0.metal_u_area.median()),
                        uncertainty_inflation=None))
    # correlated noise (zero filling + line broadening) makes the covariance too optimistic: inflate by the CAL-W250 ratio
    k_infl = float(levels[-1][3])
    # upper limit: smallest area detected (>= uncertain cut) in >= 95 % of seeds, interpolated; else extrapolated
    xs = [0] + [l[0] for l in levels]
    ps = [float(np.mean(snr0 >= unc_cut))] + [l[1] for l in levels]
    ul = None
    for (x1, p1), (x2, p2) in zip(zip(xs, ps), zip(xs[1:], ps[1:])):
        if p1 < 0.95 <= p2:
            ul = x1 + (0.95 - p1) * (x2 - x1) / (p2 - p1)
            break
    if ul is None:
        ul = float(xs[-1]) if ps[-1] >= 0.95 else float(xs[-1] * 1.3)
    # median noise of the calibration set: the upper limit scales with each spectrum's own noise
    noise_ref = float(cal0.noise_sd.median())
    gtop = fp[fp.replay == f"CALW{CAL_LEVELS[-1]}"]
    ratio = gtop.metal_area / CAL_LEVELS[-1]
    rec, rec_sd = float(ratio.mean()), float(ratio.std() / np.sqrt(len(ratio)))
    ref_cal = fp[fp.replay.isin(["CAL0"])]
    calib = {"source": "CAL0 (50 zero-metal spectra) and CALW300/600/900 (30 seeds each); fitted with the real pipeline",
             "snr_uncertain_cut": round(unc_cut, 3), "snr_detect_cut": round(det_cut, 3),
             "false_positive_rate_at_uncertain_cut": float(np.mean(snr0 >= unc_cut)), "false_positive_rate_at_detect_cut": float(np.mean(snr0 >= det_cut)),
             "upper_limit_area_au_at_reference_noise": round(float(ul), 1), "reference_noise_sd": round(noise_ref, 4),
             "upper_limit_rule": "UL = upper_limit_area_au_at_reference_noise x (spectrum noise SD / reference_noise_sd)",
             "metal_uncertainty_inflation": round(k_infl, 3),
             "peak_area_recovery_factor": round(rec, 4), "peak_area_recovery_sd": round(rec_sd, 4),
             "peak_area_recovery_reason": "mean fitted area / injected area at the highest CAL-W level: the Gaussian model misses the Lorentzian wings added by line broadening; fitted areas are divided by this factor (calibration with known injections, like a phantom)",
             "metal_uncertainty_inflation_reason": "fitted-area SD across 30 seeds / median covariance uncertainty (highest CAL-W level); processed points are correlated",
             "reference_area_sd_relative": float(ref_cal.ref_area.std() / ref_cal.ref_area.mean()),
             "reference_uncertainty_ratio_sd_over_reported": float(ref_cal.ref_area.std() / ref_cal.u_ref_area.median()),
             "levels": ncal}
    # apply inflation to the reported metal uncertainties (raw values kept)
    for c in ("u_H", "u_mu_ppm", "u_sigma_ppm", "u_area"):
        fp["metal_" + c + "_raw"] = fp["metal_" + c]
        fp["metal_" + c] = fp["metal_" + c] * k_infl
    rk = max(1.0, calib["reference_uncertainty_ratio_sd_over_reported"])
    fp["u_ref_area_raw"] = fp["u_ref_area"]
    fp["u_ref_area"] = fp["u_ref_area"] * rk
    calib["reference_uncertainty_inflation"] = round(rk, 3)
    fp.to_csv(os.path.join(root, "nmr", "fitted_peaks.csv"), index=False)
    pd.DataFrame(acqrows).to_csv(os.path.join(root, "nmr", "acquisition_parameters.csv"), index=False)
    pd.DataFrame(ncal).to_csv(os.path.join(root, "nmr", "noise_calibration.csv"), index=False)
    json.dump(calib, open(os.path.join(root, "config", "detection_calibration.json"), "w"), indent=1)
    print(json.dumps({k: v for k, v in calib.items() if k != "levels"}, indent=1))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(HERE))
