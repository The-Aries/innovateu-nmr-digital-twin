"""Step 5 — figures (PNG). Each caption names the file(s) it is drawn from.

python scripts/visualize_dataset.py [dataset_root]
Figures 02-07 use only participant-visible files (spectra, fits, twin outputs), never ground_truth/.
"""
from __future__ import annotations
import os, sys, json
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
SIM = "SIMULATED"


def spec(root, rep, c, stage):
    return pd.read_csv(os.path.join(root, "nmr", "spectra_csv", f"{rep}_{c:02d}_{stage}.csv"))


def caption(fig, text):
    fig.text(0.01, 0.005, text, fontsize=7, color="0.35")


def main(root):
    img = os.path.join(root, "images")
    os.makedirs(img, exist_ok=True)
    fp = pd.read_csv(os.path.join(root, "nmr", "fitted_peaks.csv"))
    sh = pd.read_csv(os.path.join(root, "digital_twin", "state_history.csv"))
    fc = pd.read_csv(os.path.join(root, "digital_twin", "forecasts.csv"))
    nc = pd.read_csv(os.path.join(root, "nmr", "noise_calibration.csv"))
    cal = json.load(open(os.path.join(root, "config", "detection_calibration.json")))

    # 02 paired spectra
    cyc = [2, 4, 8, 12, 16]
    fig, axes = plt.subplots(len(cyc), 2, figsize=(10, 11), sharex=True)
    for i, c in enumerate(cyc):
        for j, st in enumerate(["eoc", "pd"]):
            d = spec(root, "MAIN", c, st)
            ax = axes[i, j]
            ax.plot(d.ppm, d.intensity_au, color="0.25", lw=0.8)
            ax.axvspan(1000, 1200, color="tab:blue", alpha=0.08)
            ax.set_ylim(-5, max(40, d.intensity_au[(d.ppm > 900) & (d.ppm < 1300)].max() * 1.4))
            r = sh[(sh.replay == "MAIN") & (sh.cycle_n == c)].iloc[0]
            lab = r.eoc_detection if st == "eoc" else f"{r.detection}, QC {r.observation_qc}"
            ax.set_title(f"cycle {c}, {'end of charge' if st == 'eoc' else 'post-discharge'}: {lab}", fontsize=8)
            ax.set_xlim(1500, -300)
    for ax in axes[-1]:
        ax.set_xlabel("23Na shift (ppm)")
    for ax in axes[:, 0]:
        ax.set_ylabel("a.u.")
    fig.suptitle(f"Main replay: paired spectra ({SIM}); blue band = metal fit window 1000-1200 ppm; large line near 0 ppm = electrolyte + NaCl reference (clipped)", fontsize=9)
    caption(fig, "Source: nmr/spectra_csv/MAIN_<cycle>_<stage>.csv; labels from digital_twin/state_history.csv")
    fig.tight_layout(rect=(0, 0.02, 1, 0.97))
    fig.savefig(os.path.join(img, "02_main_paired_spectra.png"), dpi=110)
    plt.close(fig)

    # 03 overlay of post-discharge spectra
    fig, ax = plt.subplots(figsize=(9, 5))
    cmap = plt.get_cmap("viridis")
    for c in range(1, 17):
        d = spec(root, "MAIN", c, "pd")
        m = (d.ppm < 1350) & (d.ppm > 850)
        ls = ":" if c in (8, 12) else "-"
        ax.plot(d.ppm[m], d.intensity_au[m], color=cmap((c - 1) / 15), lw=1.0, ls=ls, label=f"c{c}" + (" (uncertain)" if c == 8 else " (rejected)" if c == 12 else ""))
    ax.set_xlim(1350, 850)
    ax.set_xlabel("23Na shift (ppm)")
    ax.set_ylabel("intensity (a.u.)")
    ax.legend(ncol=4, fontsize=7)
    ax.set_title(f"Post-discharge metallic-sodium region over 16 cycles ({SIM})", fontsize=10)
    caption(fig, "Source: nmr/spectra_csv/MAIN_<cycle>_pd.csv")
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(os.path.join(img, "03_main_postdischarge_overlay.png"), dpi=120)
    plt.close(fig)

    # 04 RMDI trajectory
    s = sh[sh.replay == "MAIN"]
    fig, ax = plt.subplots(figsize=(9, 5))
    q = s[(s.detection == "detected") & (s.action != "reject")]
    ax.errorbar(q.cycle_n, q.observed_rmdi, yerr=1.96 * q.observed_u, fmt="o", color="tab:blue", capsize=3, label="accepted RMDI (95 % interval)")
    nd = s[s.detection == "not_detected"]
    ax.errorbar(nd.cycle_n, nd.upper_limit, yerr=0.03, uplims=True, fmt="v", color="0.4", label="non-detection: upper limit")
    un = s[s.detection == "uncertain"]
    ax.plot(un.cycle_n, un.observed_rmdi, "s", mfc="none", color="tab:orange", ms=8, label="uncertain detection (not used)")
    rj = s[s.action == "reject"]
    ax.plot(rj.cycle_n, rj.observed_rmdi, "x", color="tab:red", ms=10, mew=2, label="rejected (QC FAIL)")
    f = fc[(fc.replay == "MAIN")]
    ax.errorbar(f.for_cycle + 0.15, f.forecast_mean, yerr=[f.forecast_mean - f.forecast_lo95, f.forecast_hi95 - f.forecast_mean], fmt="d", color="tab:green",
                mfc="white", capsize=2, alpha=0.8, label="forecast made one cycle earlier (95 %)")
    for c in (9, 14):
        r = s[s.cycle_n == c].iloc[0]
        ax.annotate(r.safety_warning.split(":")[0], (c, r.observed_rmdi), xytext=(c - 4.5, r.observed_rmdi + 0.35), fontsize=8, arrowprops=dict(arrowstyle="->", color="0.5"))
    ax.set_xlabel("cycle")
    ax.set_ylabel("RMDI = metal area / reference area (1)")
    ax.set_title(f"Twin view of the main replay: RMDI, limits, rejected points and forecasts ({SIM} data, INFERRED assessment)", fontsize=9)
    ax.legend(fontsize=7, loc="upper left")
    ax.set_xticks(range(1, 18))
    caption(fig, "Source: digital_twin/state_history.csv, digital_twin/forecasts.csv")
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(os.path.join(img, "04_main_rmdi_trajectory.png"), dpi=120)
    plt.close(fig)

    # 05 noise calibration
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(nc.injected_area_au, nc.fraction_snr_ge_uncertain_cut, "o-", label=f"SNR >= {cal['snr_uncertain_cut']:.1f} (uncertain or detected)")
    ax.plot(nc.injected_area_au, nc.fraction_snr_ge_detect_cut, "s-", label=f"SNR >= {cal['snr_detect_cut']:.1f} (detected)")
    ax.axvline(cal["upper_limit_area_au_at_reference_noise"], color="0.5", ls="--")
    ax.text(cal["upper_limit_area_au_at_reference_noise"] + 15, 0.4, f"upper limit\n{cal['upper_limit_area_au_at_reference_noise']:.0f} a.u.", fontsize=8)
    ax.axhline(0.95, color="0.8", lw=0.8)
    ax.set_xlabel("injected metal area (a.u.)")
    ax.set_ylabel("fraction of 30-50 seeds")
    ax.set_title("Noise calibration: detection probability vs injected area (CAL0, CALW300/600/900)", fontsize=9)
    ax.legend(fontsize=8)
    caption(fig, "Source: nmr/noise_calibration.csv, config/detection_calibration.json")
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(os.path.join(img, "05_noise_calibration.png"), dpi=120)
    plt.close(fig)

    # 06 V2a vs V2b
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    a = sh[sh.replay == "V2a"]
    raw = fp[(fp.replay == "V2a") & (fp.stage == "post_discharge")].sort_values("cycle_n")
    b = sh[sh.replay == "V2b"]
    ax[0].errorbar(a.cycle_n, a.observed_rmdi, yerr=1.96 * a.observed_u, fmt="o-", color="tab:blue", capsize=3)
    ax[0].set_title("V2a: gain +5 %/acquisition, reference shares it\nnormalised RMDI stays flat", fontsize=9)
    ax[0].set_ylabel("RMDI (1)")
    ax2 = ax[0].twinx()
    ax2.plot(raw.cycle_n, raw.metal_area, "s--", color="0.6")
    ax2.set_ylabel("raw fitted area (a.u., grey)", color="0.4")
    ax[1].errorbar(b.cycle_n, b.observed_rmdi, yerr=1.96 * b.observed_u, fmt="o-", color="tab:red", capsize=3)
    ax[1].set_title("V2b: same drift, no reference\nraw area rises; twin flags comparability", fontsize=9)
    ax[1].set_ylabel("calibrated area (a.u.)")
    for x in ax:
        x.set_xlabel("acquisition")
    fig.suptitle(f"Sensitivity drift: why the reference matters ({SIM})", fontsize=10)
    caption(fig, "Source: digital_twin/state_history.csv (V2a, V2b), nmr/fitted_peaks.csv")
    fig.tight_layout(rect=(0, 0.03, 1, 0.95))
    fig.savefig(os.path.join(img, "06_gain_drift_V2a_V2b.png"), dpi=120)
    plt.close(fig)

    # 07 V4 specificity control
    fig, ax = plt.subplots(figsize=(9, 4.5))
    for c in range(1, 5):
        d = spec(root, "V4", c, "eoc")
        ax.plot(d.ppm, d.intensity_au, lw=0.8, label=f"V4 cycle {c}: {sh[(sh.replay == 'V4') & (sh.cycle_n == c)].iloc[0].eoc_detection}")
    ax.axvspan(1000, 1200, color="tab:blue", alpha=0.08)
    ax.set_xlim(1500, -300)
    ax.set_ylim(-5, 40)
    ax.set_xlabel("23Na shift (ppm)")
    ax.set_ylabel("a.u.")
    ax.legend(fontsize=8)
    ax.set_title(f"Specificity control: broad quasimetallic hard-carbon signal, no metal peak ({SIM}, background ASSUMED)", fontsize=9)
    caption(fig, "Source: nmr/spectra_csv/V4_<cycle>_eoc.csv; detection from digital_twin/state_history.csv")
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(os.path.join(img, "07_specificity_control_V4.png"), dpi=120)
    plt.close(fig)
    print("figures written to", img)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(HERE))
