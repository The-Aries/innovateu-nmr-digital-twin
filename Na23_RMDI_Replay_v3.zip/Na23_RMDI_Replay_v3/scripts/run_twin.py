"""Step 3 — QC, evidence packets and the rule-based digital twin (specification §4-5).

python scripts/run_twin.py [dataset_root]

Reads: nmr/fitted_peaks.csv, metadata/*, config/thresholds.json, config/detection_calibration.json.
Never reads ground_truth/.
Writes: evidence_packets/<replay>/E-t<cycle>-<observable>.json, digital_twin/state_history.csv, decisions.csv,
forecasts.csv, digital_twin/final_state_<replay>.json.
"""
from __future__ import annotations
import os, sys, json, hashlib, math
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
TWIN_VERSION = "rmdi_twin 1.0"
REPLAYS = ["MAIN", "V1", "V2a", "V2b", "V3", "V4"]
SUBJECT = {"MAIN": "sub-cell001", "V1": "sub-cell001V1", "V2a": "sub-cell001V2a", "V2b": "sub-cell001V2b", "V3": "sub-cell001V3", "V4": "sub-cell001V4"}
STATUS_RANK = {"PASS": 0, "WARN": 1, "FAIL": 2}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def nn(x):
    return None if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))) else x


def rnd(x, k=4):
    x = nn(x)
    return None if x is None else round(float(x), k)


# ------------------------------------------------------------------------------------------------ measurement layer
def ref_detected(row, T):
    conv = row.get("converged") is True or str(row.get("converged")) in ("True", "1.0", "1")
    return bool(conv and (nn(row.get("ref_snr")) or 0) >= T["reference_detected_min_snr"]
                and (nn(row.get("ref_fwhm_ppm")) or 99) <= T["reference_max_fwhm_ppm"])

def measure(row, meta, T, cal, ref_baseline, root):
    """Detection class, calibrated area, RMDI and the QC checks for one spectrum."""
    C = T["checks"]
    checks = []

    def add(name, value, unit, threshold, status, owner, note=""):
        checks.append({"name": name, "value": nn(value), "unit": unit, "threshold": threshold, "status": status, "owner": owner, **({"note": note} if note else {})})

    ref_ok = ref_detected(row, T)
    # 1 reference shift
    c = C["reference_shift_error_ppm"]
    if ref_ok:
        v = abs(row["ref_shift_ppm"])
        st = "PASS" if v <= c["pass_max"] else "WARN" if v <= c["warn_max"] else "FAIL"
        add("reference_shift_error", round(v, 3), "ppm", f"PASS <= {c['pass_max']}; WARN <= {c['warn_max']}", st, c["owner"])
    else:
        add("reference_shift_error", None, "ppm", "reference must be detected", "WARN", c["owner"], "reference not detected: frequency not verifiable")
    # 2 delay
    c = C["scan_delay_min"]
    v = float(meta["scan_delay_min"])
    st = "PASS" if c["pass_range"][0] <= v <= c["pass_range"][1] else "WARN" if v <= c["warn_max"] else "FAIL"
    add("scan_delay", v, "min", f"PASS {c['pass_range'][0]}-{c['pass_range'][1]}; WARN <= {c['warn_max']}", st, c["owner"])
    # 3 temperature
    c = C["cell_temperature_dev_K"]
    v = abs(float(meta["cell_temperature_C"]) - c["nominal_C"])
    st = "PASS" if v <= c["pass_max"] else "WARN" if v <= c["warn_max"] else "FAIL"
    add("cell_temperature_deviation", round(v, 2), "K", f"PASS <= {c['pass_max']}; WARN <= {c['warn_max']}", st, c["owner"])
    # 4 reference area ratio (sensitivity / comparability)
    c = C["reference_area_ratio"]
    ratio = None
    if ref_ok and ref_baseline:
        ratio = row["ref_area"] / ref_baseline
        st = "PASS" if c["pass_range"][0] <= ratio <= c["pass_range"][1] else "WARN" if c["warn_range"][0] <= ratio <= c["warn_range"][1] else "FAIL"
        add("reference_area_ratio", round(ratio, 3), "1", f"PASS {c['pass_range']}; WARN {c['warn_range']}", st, c["owner"])
    else:
        add("reference_area_ratio", None, "1", "reference required for normalisation", "WARN", c["owner"],
            "no trustworthy reference: comparability between sessions not demonstrated")
    # 5 detection limit
    c = C["detection_limit_au"]
    ul = cal["upper_limit_area_au_at_reference_noise"] * row["noise_sd"] / cal["reference_noise_sd"]
    ul0 = cal["upper_limit_area_au_at_reference_noise"]
    st = "PASS" if ul <= c["pass_factor"] * ul0 else "WARN" if ul <= c["warn_factor"] * ul0 else "FAIL"
    add("detection_limit", round(ul, 1), "a.u.", f"PASS <= {c['pass_factor'] * ul0:.0f}; WARN <= {c['warn_factor'] * ul0:.0f}", st, c["owner"])
    # detection class (separate from QC)
    snr = nn(row.get("metal_snr")) or 0.0
    at_bound = str(row.get("metal_at_bound")) == "True"
    if snr >= cal["snr_detect_cut"] and not at_bound:
        det = "detected"
    elif snr >= cal["snr_uncertain_cut"] and not at_bound:
        det = "uncertain"
    else:
        det = "not_detected"
    # 6 fit validity
    c = C["fit_validity"]
    if det in ("detected", "uncertain"):
        chi = row["metal_reduced_chi2"]
        inrange = c["mu_range_ppm"][0] < row["metal_mu_ppm"] < c["mu_range_ppm"][1] and c["sigma_range_ppm"][0] < row["metal_sigma_ppm"] < c["sigma_range_ppm"][1]
        st = "FAIL" if (not inrange or chi > c["chi2_warn_max"]) else "WARN" if chi > c["chi2_pass_max"] else "PASS"
        add("fit_validity", round(chi, 3), "reduced chi2", f"converged, mu {c['mu_range_ppm']}, sigma {c['sigma_range_ppm']}; PASS chi2 <= {c['chi2_pass_max']}; WARN <= {c['chi2_warn_max']}", st, c["owner"])
    else:
        add("fit_validity", None, "reduced chi2", "applies only to fitted peaks", "PASS", c["owner"],
            "no peak above the uncertain cut" + ("; best fit sat at a parameter bound" if at_bound else ""))
    # 7 metadata / provenance
    c = C["metadata_provenance"]
    src = os.path.join(root, row["source_object"])
    ok_src = os.path.exists(src)
    have = {"nucleus": True, "spectrometer_frequency_MHz": True, "number_of_scans": True, "scan_delay_min": not pd.isna(meta["scan_delay_min"]),
            "cell_temperature_C": not pd.isna(meta["cell_temperature_C"]), "source_sha256": ok_src, "processing_version": bool(row["processing_version"])}
    missing = [k for k, v in have.items() if not v]
    add("metadata_provenance", "complete" if not missing else "missing: " + ",".join(missing), "", "all required fields present; source hash computable",
        "PASS" if not missing else "FAIL", c["owner"])
    qc = max((x["status"] for x in checks), key=lambda s: STATUS_RANK[s])
    reasons = [f"{x['name']} {x['status']}" + (f" ({x['value']} {x['unit']})" if x["value"] is not None else (f": {x.get('note', '')}")) for x in checks if x["status"] != "PASS"]
    # calibrated area: fitted / recovery factor; uncertainty incl. model mismatch and recovery uncertainty
    rec, u_rec = cal["peak_area_recovery_factor"], cal["peak_area_recovery_sd"]
    A = row["metal_area"] / rec
    uA_ind = math.sqrt((row["metal_u_area"] / rec) ** 2 + (T["twin"]["model_mismatch_relative_sd"] * A) ** 2)   # varies cycle to cycle
    uA = math.sqrt(uA_ind ** 2 + (A * u_rec / rec) ** 2)        # + recovery-factor term, common to all cycles
    out = dict(qc_status=qc, qc_checks=checks, qc_reasons=reasons, detection=det, snr=snr, upper_limit_au=ul / rec, ref_ok=ref_ok,
               ref_ratio=ratio, area_au=A, u_area_au=uA, sha=sha256(src) if ok_src else None)
    if ref_ok:
        out["normalisation"] = "reference_capillary"
        out["rmdi"] = A / row["ref_area"]
        out["u_rmdi"] = out["rmdi"] * math.sqrt((uA / A) ** 2 + (row["u_ref_area"] / row["ref_area"]) ** 2) if A > 0 else uA / row["ref_area"]
        out["rmdi_upper_limit"] = out["upper_limit_au"] / row["ref_area"]
        out["u_rmdi_ind"] = out["rmdi"] * math.sqrt((uA_ind / A) ** 2 + (row["u_ref_area"] / row["ref_area"]) ** 2) if A > 0 else uA_ind / row["ref_area"]
    else:
        out["normalisation"] = "none_au"
        out["rmdi"], out["u_rmdi"], out["rmdi_upper_limit"], out["u_rmdi_ind"] = A, uA, out["upper_limit_au"], uA_ind
    return out


# ------------------------------------------------------------------------------------------------ packets
def packet(replay, cycle, stage, m, row, meta, t_rel, twin_action, reason, processing_version):
    obs = "rmdi" if stage == "post_discharge" else "eoc_metal_area"
    quantitative = m["detection"] == "detected" and m["qc_status"] != "FAIL"
    if stage == "post_discharge":
        value = rnd(m["rmdi"], 5) if quantitative else None
        unit = "1" if m["normalisation"] == "reference_capillary" else "a.u."
        unc = {"type": "SD", "value": rnd(m["u_rmdi"], 5)} if quantitative else {"type": "category", "value": "uncertain detection" if m["detection"] == "uncertain" else "non-detection"}
        vr = [0, 5] if unit == "1" else [0, 100000]
    else:
        value = rnd(m["area_au"], 2) if quantitative else None
        unit, vr = "a.u.", [0, 100000]
        unc = {"type": "SD", "value": rnd(m["u_area_au"], 2)} if quantitative else {"type": "category", "value": "uncertain detection" if m["detection"] == "uncertain" else "non-detection"}
    unc["budget_ref"] = "documentation/methodology.md#uncertainty-budget"
    p = {
        "packet_version": "1.0", "packet_id": f"E-t{cycle}-{obs}", "subject_id": SUBJECT[replay], "session_id": f"ses-{replay}c{cycle:02d}",
        "cell_id": "cell-001", "replay": replay, "cycle_n": int(cycle), "relative_time": {"value": round(t_rel, 1), "unit": "s"},
        "modality": "MRS", "nucleus": "23Na", "measurement_stage": stage,
        "source_object": row["source_object"], "source_sha256": m["sha"],
        "spatial_reference": {"frame": "named_region", "region": "coil-sensitive volume of cell-001 (no imaging coordinates)"},
        "observable": obs, "value": value, "unit": unit, "valid_range": vr, "uncertainty": unc,
        "detection_class": m["detection"], "fitted_snr": rnd(m["snr"], 2),
        "upper_limit": rnd(m["rmdi_upper_limit"] if stage == "post_discharge" else m["upper_limit_au"], 5) if not quantitative else None,
        "fitted_value_not_used": (rnd(m["rmdi"] if stage == "post_discharge" else m["area_au"], 5) if (m["detection"] == "uncertain") else None),
        "raw_area_au": rnd(m["area_au"], 2), "u_raw_area_au": rnd(m["u_area_au"], 2),
        "peak": {"mu_ppm": rnd(row["metal_mu_ppm"], 2), "u_mu_ppm": rnd(row["metal_u_mu_ppm"], 2), "sigma_ppm": rnd(row["metal_sigma_ppm"], 2),
                 "H": rnd(row["metal_H"], 3), "reduced_chi2": rnd(row["metal_reduced_chi2"], 3)},
        "reference": {"area": rnd(row.get("ref_area"), 1), "u_area": rnd(row.get("u_ref_area"), 1), "shift_ppm": rnd(row.get("ref_shift_ppm"), 3),
                      "detected": bool(m["ref_ok"]), "area_ratio_to_baseline": rnd(m["ref_ratio"], 4)},
        "normalisation": m["normalisation"], "protocol_match": True, "comparable": bool(m["ref_ok"]),
        "qc_checks": m["qc_checks"], "qc_status": m["qc_status"], "qc_reasons": m["qc_reasons"],
        "system_qc_id": f"sysqc-{replay}-c{cycle:02d}", "calibration_id": "detection_calibration.json",
        "origin": "SIMULATED", "value_epistemic": "DERIVED", "decision_epistemic": "INFERRED",
        "acquisition_context": {"field_strength_T": 9.4, "spectrometer_frequency_MHz": 105.855213, "sequence": "zg_se1.gep", "TR_s": 0.051, "averages": int(meta["number_of_scans"]),
                                "scan_delay_min": float(meta["scan_delay_min"]), "cell_temperature_C": float(meta["cell_temperature_C"]),
                                "charging": "30 mA/g fixed; upper voltage 4.2 V (ASSUMED); lower voltage not specified", "reference_type": meta["reference_type"]},
        "processing": {"pipeline": "Na23 RMDI pipeline", "version": processing_version, "fit": row["fit_version"], "twin": TWIN_VERSION},
        "provenance": {"parents": [row["source_object"], f"nmr/fitted_peaks.csv#{replay}/{row['expno']}"],
                       "activities": ["generate_dataset (SIMULATED acquisition)", f"process {processing_version}: LB, zero fill, FFT, phase, baseline",
                                      "Gaussian fit 1000-1200 ppm + time-domain reference fit", "QC (config/thresholds.json)", "packet build"]},
        "twin_action": {"recommended": twin_action, "reason": reason},
        "interpretation_limit": "NMR-visible metallic sodium signal (RMDI); not deposited mass, thickness, capacity fade or failure probability; synthetic data",
    }
    return p


# ------------------------------------------------------------------------------------------------ twin
def wls_line(xs, ys, us):
    xs, ys, us = map(np.asarray, (xs, ys, us))
    w = 1.0 / np.maximum(us, 1e-12) ** 2
    X = np.c_[np.ones_like(xs), xs]
    C = np.linalg.inv(X.T @ (w[:, None] * X))
    b = C @ (X.T @ (w * ys))
    r = ys - X @ b
    chi = float(np.sum(w * r ** 2) / max(len(xs) - 2, 1)) if len(xs) > 2 else 1.0
    return b, C * max(chi, 1.0)


def run_replay(replay, P, T):
    tw = T["twin"]
    k = tw["significance_k"]
    hist, rows, fcs = [], [], []
    state = {"cell_id": "cell-001", "replay": replay, "cycle_n": None, "rmdi_history": [], "rmdi_current": None, "rmdi_uncertainty": None,
             "normalisation": None, "health_trend": "undetermined", "safety_warning": "assessment unavailable: no quantitative observation yet",
             "forecast_next_cycle": None, "last_valid_cycle": None, "evidence_ids": [], "state_version": 0}
    current_out, prev_candidate = "keep_current", None
    warning_level, slope_up_count = 0, 0
    pending_fc = None
    cycles = sorted({c for (c, s) in P})
    for c in cycles:
        pdp, eoc = P.get((c, "post_discharge")), P.get((c, "end_of_charge"))
        prior = {k2: state[k2] for k2 in ("rmdi_current", "rmdi_uncertainty", "health_trend", "safety_warning", "state_version")}
        reasons, action, trend = [], None, state["health_trend"]
        delta = u_delta = z_fc = None
        fc_eval = None
        if pdp is None:
            action, trend = "no_observation", "undetermined"
            reasons.append("no post-discharge spectrum this cycle: no value invented")
        else:
            m = pdp["_m"]
            qc, det = m["qc_status"], m["detection"]
            if qc == "FAIL":
                action = "reject"
                reasons.append("QC FAIL: " + "; ".join(m["qc_reasons"]) + ". Evidence kept, accepted state unchanged")
                trend = "undetermined"
            elif det == "not_detected":
                action = "update" if qc == "PASS" else "update_with_warning"
                reasons.append(f"non-detection stored as upper limit RMDI < {m['rmdi_upper_limit']:.4g} ({m['normalisation']}); not zero")
                trend = "undetermined" if state["rmdi_current"] is None else state["health_trend"]
            elif det == "uncertain":
                action = "update_with_warning"
                reasons.append(f"uncertain detection (SNR {m['snr']:.1f}): ambiguity kept, last accepted RMDI kept")
                trend = "undetermined"
            else:
                action = "update" if qc == "PASS" else "update_with_warning"
                comparable_ok = m["normalisation"] == "reference_capillary"
                y, u = m["rmdi"], m["u_rmdi_ind"]     # cycle-to-cycle part only: the recovery-factor error is common and cancels in differences
                if qc == "WARN":
                    u = u * math.sqrt(2.0)
                    reasons.append("WARN evidence: uncertainty inflated by sqrt(2): " + "; ".join(m["qc_reasons"]))
                last = next((h for h in reversed(state["rmdi_history"]) if h["quantitative"] and h["normalisation"] == m["normalisation"]), None)
                if pending_fc is not None:
                    z_fc = (y - pending_fc["mean"]) / math.sqrt(pending_fc["sd"] ** 2 + u ** 2)
                    fc_eval = pending_fc
                if last is not None:
                    delta = y - last["rmdi"]
                    u_delta = math.sqrt(u ** 2 + last["u"] ** 2)
                    if not comparable_ok:
                        trend = "undetermined"
                        reasons.append(f"change {delta:+.4g} a.u. but no trustworthy reference: comparability not demonstrated, no accumulation claimed")
                    elif delta > k * u_delta:
                        trend = "deteriorating"
                        reasons.append(f"significant increase {delta:+.4g} > {k} x {u_delta:.3g}")
                    else:
                        trend = "stable"
                        reasons.append(f"change {delta:+.4g} within {k} x {u_delta:.3g}: stable within measurement resolution (not proof of no degradation)")
                else:
                    trend = "undetermined"
                    reasons.append("first quantitative RMDI")
                state["rmdi_current"], state["normalisation"] = y, m["normalisation"]
                state["rmdi_uncertainty"] = m["u_rmdi"] * (math.sqrt(2) if qc == "WARN" else 1)    # full uncertainty (incl. common terms)
                state["last_valid_cycle"] = c
            state["evidence_ids"].append(pdp["packet_id"])
            state["rmdi_history"].append({"cycle_n": c, "rmdi": m["rmdi"] if det == "detected" and qc != "FAIL" else None,
                                          "u": (m["u_rmdi_ind"] * (math.sqrt(2) if qc == "WARN" else 1)) if det == "detected" else None,
                                          "upper_limit": m["rmdi_upper_limit"] if det == "not_detected" else None, "detection": det,
                                          "qc_status": qc, "action": action, "normalisation": m["normalisation"],
                                          "quantitative": det == "detected" and qc != "FAIL"})
        # forecast discrepancy record
        if fc_eval is not None:
            fcs[-1].update(actual=state["rmdi_current"], z=z_fc, within_95=abs(z_fc) <= 1.96)
        pending_fc = None
        # trend over recent quantitative points
        q = [h for h in state["rmdi_history"] if h["quantitative"] and h["normalisation"] == state["normalisation"]]
        slope_sig = False
        slope_txt = ""
        if len(q) >= 3 and state["normalisation"] == "reference_capillary":
            win = q[-tw["forecast_window"]:]
            b, Cb = wls_line([h["cycle_n"] for h in win], [h["rmdi"] for h in win], [h["u"] for h in win])
            slope, us = b[1], math.sqrt(Cb[1, 1])
            slope_sig = slope > k * us
            nxt = c + 1
            mean = b[0] + b[1] * nxt
            var = Cb[0, 0] + 2 * nxt * Cb[0, 1] + nxt ** 2 * Cb[1, 1]
            sd = math.sqrt(var + q[-1]["u"] ** 2)
            state["forecast_next_cycle"] = {"cycle_n": nxt, "mean": mean, "lo95": mean - 1.96 * sd, "hi95": mean + 1.96 * sd,
                                            "method": f"weighted linear trend of the last {len(win)} quantitative points"}
            pending_fc = {"mean": mean, "sd": sd}
            fcs.append(dict(replay=replay, made_at_cycle=c, for_cycle=nxt, forecast_mean=mean, forecast_lo95=mean - 1.96 * sd, forecast_hi95=mean + 1.96 * sd,
                            slope_per_cycle=slope, u_slope=us, n_points=len(win), actual=None, z=None, within_95=None))
            slope_txt = f"slope {slope:+.4g}/cycle (u {us:.2g})"
            # acceleration: last slope_window points vs the slope_window points before them
            sw = tw["slope_window"]
            if len(q) >= 2 * sw:
                b1, C1 = wls_line([h["cycle_n"] for h in q[-sw:]], [h["rmdi"] for h in q[-sw:]], [h["u"] for h in q[-sw:]])
                b0, C0 = wls_line([h["cycle_n"] for h in q[-2 * sw:-sw]], [h["rmdi"] for h in q[-2 * sw:-sw]], [h["u"] for h in q[-2 * sw:-sw]])
                dz = (b1[1] - b0[1]) / math.sqrt(C1[1, 1] + C0[1, 1])
                earlier_rising = b0[1] > k * math.sqrt(C0[1, 1])        # accumulation already established before
                slope_up_count = slope_up_count + 1 if (dz > k and earlier_rising) else 0
                slope_txt += f"; slope change z = {dz:.2f}"
        else:
            state["forecast_next_cycle"] = {"cycle_n": c + 1, "mean": None, "status": "insufficient evidence: fewer than 3 quantitative observations"
                                            if state["normalisation"] != "none_au" else "unavailable: no trustworthy normalisation"}
        if slope_sig and trend == "stable" and pdp is not None and pdp["_m"]["detection"] == "detected" and pdp["_m"]["qc_status"] != "FAIL":
            trend = "deteriorating"
            reasons.append("single step within resolution, but the recent trend is significantly positive (" + slope_txt + ")")
        # warning level
        if pdp is not None and pdp["_m"]["qc_status"] != "FAIL" and pdp["_m"]["detection"] == "detected" and state["normalisation"] == "reference_capillary":
            if slope_up_count >= tw["persistence_cycles"]:
                warning_level = 2
            elif trend == "deteriorating" or slope_sig:
                warning_level = max(warning_level, 1)
        warn_txt = {0: "no evidence of increasing residual deposition" if state["rmdi_current"] is not None else "assessment unavailable: no quantitative observation yet",
                    1: "accumulation warning", 2: "elevated concern: accelerating accumulation; further investigation recommended"}[warning_level]
        if state["normalisation"] == "none_au" and state["rmdi_current"] is not None:
            warn_txt = "assessment uncertain: no trustworthy reference, comparability not demonstrated"
        state["health_trend"], state["safety_warning"] = trend, warn_txt
        # next measurement
        m = pdp["_m"] if pdp is not None else None
        if m is None:
            nm, why = "routine_post_discharge", "no spectrum this cycle: measure after the next standardised discharge"
        elif m["qc_status"] == "FAIL" and any(x["status"] == "FAIL" and x["name"] in ("reference_shift_error", "reference_area_ratio") for x in m["qc_checks"]):
            nm, why = "check_reference_calibration", "calibration failure: verify frequency and sensitivity reference before interpreting the trend"
        elif m["qc_status"] == "FAIL":
            nm, why = "repeat_spectrum", "measurement conditions out of limits: repeat within the declared window"
        elif m["detection"] == "uncertain":
            nm, why = "improve_snr", "ambiguous detection: repeat with more scans / better SNR"
        elif not m["ref_ok"] or any(x["status"] != "PASS" and x["name"] == "reference_area_ratio" for x in m["qc_checks"]):
            nm, why = "check_reference_calibration", "sensitivity changed or reference missing: comparability must be demonstrated"
        elif warning_level == 2:
            nm, why = "expert_review", "accelerating accumulation supported by several observations"
        elif z_fc is not None and abs(z_fc) > 1.96 and (delta or 0) > 0:
            nm, why = "confirmatory_measurement", f"observation outside the forecast interval (z = {z_fc:.2f}): confirm and inspect competing explanations"
        elif any(x["status"] == "WARN" for x in m["qc_checks"]):
            nm, why = "repeat_spectrum", "WARN evidence: repeat under nominal conditions"
        else:
            nm, why = "routine_post_discharge", "reliable observation: measure again after the next standardised discharge"
        # current suggestion (next cycle only), with persistence
        eoc_det = eoc is not None and eoc["_m"]["detection"] == "detected" and eoc["_m"]["qc_status"] != "FAIL"
        if m is None or m["qc_status"] == "FAIL" or m["detection"] == "uncertain" or not m["ref_ok"]:
            cand, cwhy = "insufficient_evidence", "post-discharge evidence missing, rejected, ambiguous or not comparable"
        elif eoc_det or trend == "deteriorating" or warning_level >= 1:
            cand = "reduce_current"
            cwhy = ("metal detected at end of charge" if eoc_det else "") + ("; " if eoc_det and (trend == "deteriorating" or warning_level) else "") + \
                   ("significant post-discharge increase / accumulation warning" if (trend == "deteriorating" or warning_level) else "")
        else:
            cand, cwhy = "keep_current", "no end-of-charge metal and no significant post-discharge increase"
        if cand == prev_candidate:
            current_out = cand
        prev_candidate = cand
        state["cycle_n"] = c
        state["state_version"] += 1
        rows.append(dict(replay=replay, cycle_n=c, state_version=state["state_version"],
                         prior_rmdi=rnd(prior["rmdi_current"], 5), prior_trend=prior["health_trend"],
                         observation_packet=pdp["packet_id"] if pdp else None, observation_qc=pdp["_m"]["qc_status"] if pdp else None,
                         detection=pdp["_m"]["detection"] if pdp else None, observed_rmdi=rnd(pdp["_m"]["rmdi"], 5) if (pdp and pdp["_m"]["detection"] != "not_detected") else None,
                         observed_u=rnd(pdp["_m"]["u_rmdi"], 5) if (pdp and pdp["_m"]["detection"] != "not_detected") else None, upper_limit=rnd(pdp["_m"]["rmdi_upper_limit"], 5) if (pdp and pdp["_m"]["detection"] == "not_detected") else None,
                         normalisation=pdp["_m"]["normalisation"] if pdp else None, action=action, delta=rnd(delta, 5), u_delta=rnd(u_delta, 5),
                         rmdi_current=rnd(state["rmdi_current"], 5), rmdi_uncertainty=rnd(state["rmdi_uncertainty"], 5), last_valid_cycle=state["last_valid_cycle"],
                         health_trend=trend, safety_warning=warn_txt, trend_detail=slope_txt,
                         forecast_next_mean=rnd(state["forecast_next_cycle"].get("mean"), 5) if state["forecast_next_cycle"] else None,
                         forecast_next_lo95=rnd(state["forecast_next_cycle"].get("lo95"), 5), forecast_next_hi95=rnd(state["forecast_next_cycle"].get("hi95"), 5),
                         eoc_packet=eoc["packet_id"] if eoc else None, eoc_detection=eoc["_m"]["detection"] if eoc else None,
                         recommended_next_measurement=nm, next_measurement_reason=why,
                         charging_candidate=cand, charging_suggestion_next_cycle=current_out, charging_reason=cwhy,
                         reasons=" | ".join(reasons), origin="INFERRED (twin) from DERIVED evidence of SIMULATED spectra"))
    return rows, fcs, state


def main(root):
    T = json.load(open(os.path.join(root, "config", "thresholds.json")))
    cal = json.load(open(os.path.join(root, "config", "detection_calibration.json")))
    fp = pd.read_csv(os.path.join(root, "nmr", "fitted_peaks.csv"))
    idx = pd.read_csv(os.path.join(root, "metadata", "spectra_index.csv"))
    fp = fp.merge(idx[["replay", "cycle_n", "stage", "scan_delay_min", "cell_temperature_C", "number_of_scans", "reference_type", "acquisition_start"]],
                  on=["replay", "cycle_n", "stage"], how="left")
    t0 = pd.to_datetime(idx.acquisition_start).min()
    all_rows, all_fc, decisions = [], [], []
    os.makedirs(os.path.join(root, "digital_twin"), exist_ok=True)
    for rep in REPLAYS:
        g = fp[fp.replay == rep]
        if g.empty:
            continue
        # reference baseline: mean reference area of the first two cycles with a detected reference
        pdg = g[(g.stage == "post_discharge")].sort_values("cycle_n")
        ok = pdg[[ref_detected(r, T) for r in pdg.to_dict("records")]]
        ref_base = float(ok.ref_area.head(2).mean()) if len(ok) else None
        P = {}
        pdir = os.path.join(root, "evidence_packets", rep)
        os.makedirs(pdir, exist_ok=True)
        for r in g.sort_values(["cycle_n", "stage"]).to_dict("records"):
            base = ref_base
            if r["stage"] == "end_of_charge":
                eg = g[g.stage == "end_of_charge"].sort_values("cycle_n")
                okc = eg[[ref_detected(x, T) for x in eg.to_dict("records")]]
                base = float(okc.ref_area.head(2).mean()) if len(okc) else None
            m = measure(r, r, T, cal, base, root)
            ta = "reject" if m["qc_status"] == "FAIL" else ("update_with_warning" if (m["qc_status"] == "WARN" or m["detection"] == "uncertain") else "update")
            reason = {"reject": "QC FAIL: " + "; ".join(m["qc_reasons"]),
                      "update_with_warning": "usable with caution: " + ("; ".join(m["qc_reasons"]) or f"detection {m['detection']}"),
                      "update": "PASS evidence" + (" (non-detection: upper limit)" if m["detection"] == "not_detected" else "")}[ta]
            t_rel = (pd.to_datetime(r["acquisition_start"]) - t0).total_seconds()
            pk = packet(rep, int(r["cycle_n"]), r["stage"], m, r, r, t_rel, ta, reason, f"{float(r['processing_version']):.1f}")
            json.dump(pk, open(os.path.join(pdir, f"{pk['packet_id']}.json"), "w"), indent=1)
            pk["_m"] = m
            P[(int(r["cycle_n"]), r["stage"])] = pk
        rows, fcs, state = run_replay(rep, P, T)
        all_rows += rows
        all_fc += fcs
        json.dump(state, open(os.path.join(root, "digital_twin", f"final_state_{rep}.json"), "w"), indent=1, default=float)
    sh = pd.DataFrame(all_rows)
    sh.to_csv(os.path.join(root, "digital_twin", "state_history.csv"), index=False)
    sh[["replay", "cycle_n", "state_version", "action", "health_trend", "safety_warning", "recommended_next_measurement", "next_measurement_reason",
        "charging_suggestion_next_cycle", "charging_reason"]].to_csv(os.path.join(root, "digital_twin", "decisions.csv"), index=False)
    pd.DataFrame(all_fc).to_csv(os.path.join(root, "digital_twin", "forecasts.csv"), index=False)
    print(sh[sh.replay == "MAIN"][["cycle_n", "observation_qc", "detection", "observed_rmdi", "action", "health_trend", "safety_warning",
                                    "recommended_next_measurement", "charging_suggestion_next_cycle"]].to_string())


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(HERE))
