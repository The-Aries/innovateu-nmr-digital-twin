"""Run the whole pipeline in order. Optional: pass the paths of Figure_5.zip and Figure_6.zip to refit the real data.

python scripts/run_all.py [Figure_5.zip Figure_6.zip]
"""
import os, sys, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def run(name, *args):
    print(f"--- {name}")
    subprocess.run([sys.executable, os.path.join(HERE, name), *args], check=True)


if __name__ == "__main__":
    zips = [a for a in sys.argv[1:] if a.endswith(".zip")]
    if zips:
        run("analyse_real_data.py", *zips, ROOT)
    run("generate_dataset.py", ROOT)
    run("fit_spectra.py", ROOT)
    run("run_twin.py", ROOT)
    run("evaluate.py", ROOT)
    run("visualize_dataset.py", ROOT)
    run("make_tests.py", ROOT)
    run("make_manifest.py", ROOT)
    run("validate_dataset.py", ROOT)
