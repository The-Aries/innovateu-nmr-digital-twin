"""Write dataset_manifest.csv: path, bytes and SHA-256 of every file (except the manifest and the validation report)."""
import os, sys, hashlib, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))


def main(root):
    rows = []
    for d, ds, fs in os.walk(root):
        ds[:] = [x for x in ds if x not in ("__pycache__", ".pytest_cache")]
        for f in sorted(fs):
            p = os.path.join(d, f)
            rel = os.path.relpath(p, root).replace(os.sep, "/")
            if rel in ("dataset_manifest.csv", "documentation/validation_report.json"):
                continue
            rows.append(dict(path=rel, bytes=os.path.getsize(p), sha256=hashlib.sha256(open(p, "rb").read()).hexdigest()))
    pd.DataFrame(rows).sort_values("path").to_csv(os.path.join(root, "dataset_manifest.csv"), index=False)
    print(len(rows), "files in manifest")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(HERE))
