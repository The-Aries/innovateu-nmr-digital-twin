"""Build the deliberately broken packets used by the regression tests (no new spectra: an existing packet is modified).

python scripts/make_tests.py [dataset_root]   ->  tests/packets/*.json
"""
import os, sys, json, copy

HERE = os.path.dirname(os.path.abspath(__file__))


def main(root):
    src = json.load(open(os.path.join(root, "evidence_packets", "MAIN", "E-t10-rmdi.json")))
    out = os.path.join(root, "tests", "packets")
    os.makedirs(out, exist_ok=True)
    cases = {}
    p = copy.deepcopy(src); p["unit"] = "mg"; cases["wrong_units.json"] = p
    p = copy.deepcopy(src); p.pop("source_object"); cases["missing_source.json"] = p
    p = copy.deepcopy(src); p["source_sha256"] = "0" * 64; cases["wrong_sha256.json"] = p
    p = copy.deepcopy(src); p["processing"]["version"] = "1.1"; cases["processing_version_1_1.json"] = p
    p = copy.deepcopy(src); p["origin"] = "MEASURED"; cases["synthetic_labelled_measured.json"] = p
    for k, v in cases.items():
        v["test_case_note"] = "deliberately modified copy of evidence_packets/MAIN/E-t10-rmdi.json for regression tests"
        json.dump(v, open(os.path.join(out, k), "w"), indent=1)
    print("wrote", len(cases), "test packets")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(HERE))
