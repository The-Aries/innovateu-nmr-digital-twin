"""Processing used for BOTH the real Birmingham spectra and the synthetic spectra (pipeline version 1.0):
group-delay removal -> exponential line broadening -> zero fill -> FFT -> zero-order phase -> polynomial baseline.
"""
from __future__ import annotations
import numpy as np

PIPELINE_VERSION = "1.0"
PROC_V10 = {"LB_Hz": 1500.0, "SI": 2048, "baseline_order": 2,
            "baseline_regions_ppm": [(1700.0, 1350.0), (-350.0, -630.0)]}
PROC_V11 = {"LB_Hz": 2000.0, "SI": 2048, "baseline_order": 3,
            "baseline_regions_ppm": [(1700.0, 1350.0), (-350.0, -630.0)]}
PROCS = {"1.0": PROC_V10, "1.1": PROC_V11}


def ppm_axis(offset_ppm, sw_hz, sf_mhz, si):
    """Exact axis of fft_spectrum(): bins at fftshift(fftfreq) reversed, around the carrier.
    offset_ppm is the acquisition OFFSET (left edge of the full spectral width)."""
    center = offset_ppm - (sw_hz / sf_mhz) / 2.0
    freqs = np.fft.fftshift(np.fft.fftfreq(si, 1.0 / sw_hz))[::-1]
    return center + freqs / sf_mhz


def fft_spectrum(fid, sw_hz, lb_hz, si, grpdly=0.0):
    n = len(fid)
    t = np.arange(n) / sw_hz
    f = fid * np.exp(-np.pi * lb_hz * t)
    f[0] *= 0.5
    spec = np.fft.fftshift(np.fft.fft(f, si))
    if grpdly:
        k = np.arange(si) - si / 2
        spec = spec * np.exp(2j * np.pi * grpdly * k / si)
    return spec[::-1]            # descending frequency = descending ppm


def autophase0(spec):
    """Zero-order phase maximising the positive real integral (robust for these mostly absorptive spectra)."""
    best, bp = -np.inf, 0.0
    for ph in np.linspace(-np.pi, np.pi, 721):
        r = (spec * np.exp(1j * ph)).real
        score = r.sum() - 4.0 * np.abs(np.minimum(r, 0)).sum()
        if score > best:
            best, bp = score, ph
    return bp


def baseline(ppm, y, regions, order):
    m = np.zeros_like(ppm, bool)
    for hi, lo in regions:
        m |= (ppm <= hi) & (ppm >= lo)
    c = np.polyfit(ppm[m] / 1000.0, y[m], order)
    return y - np.polyval(c, ppm / 1000.0), m


def process(fid, acq, version="1.0", phase=None):
    """acq needs SW_h, SFO1 (MHz), OFFSET_ppm and optional GRPDLY. Returns ppm, real spectrum, info."""
    P = PROCS[version]
    spec = fft_spectrum(fid, acq["SW_h"], P["LB_Hz"], P["SI"], acq.get("GRPDLY", 0.0))
    ph = autophase0(spec) if phase is None else phase
    y = (spec * np.exp(1j * ph)).real
    ppm = ppm_axis(acq["OFFSET_ppm"], acq["SW_h"], acq["SF"], P["SI"])
    y, m = baseline(ppm, y, P["baseline_regions_ppm"], P["baseline_order"])
    noise = float(np.std(y[m]))
    return ppm, y, {"phase_rad": float(ph), "noise_sd": noise, "pipeline_version": version, **P}
