"""Step 0 — read and fit the real Birmingham spectra (Bray et al. 2020) with the same Gaussian fitter.

python scripts/analyse_real_data.py <Figure_5.zip> [<Figure_6.zip>] [dataset_root]

The original archives are NOT modified and NOT redistributed here; they are listed with SHA-256 in
experimental_reference/source_manifest.csv. Download: https://edata.bham.ac.uk/456/
Writes experimental_reference/real_fits.csv, real_electrochemistry_summary.json and images/01_real_bray_fit.png.
"""
from __future__ import annotations
import os, sys, json, hashlib, zipfile, tempfile, glob
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bruker as B, fitting as F


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def main(zips, root):
    out = os.path.join(root, "experimental_reference")
    os.makedirs(out, exist_ok=True)
    os.makedirs(os.path.join(root, "images"), exist_ok=True)
    man, rows = [], []
    tmp = tempfile.mkdtemp()
    for z in zips:
        man.append(dict(file=os.path.basename(z).split("-", 1)[-1] if "-" in os.path.basename(z)[:9] else os.path.basename(z), bytes=os.path.getsize(z),
                        sha256=sha256(z), source="https://edata.bham.ac.uk/456/ (Bray et al., Nat. Commun. 11, 2083, 2020)",
                        label="MEASURED (original, unmodified, not redistributed)"))
        d = os.path.join(tmp, os.path.basename(z))
        with zipfile.ZipFile(z) as zf:
            zf.extractall(d)
    exps = sorted(e for e in glob.glob(os.path.join(tmp, "*", "**", "acqus"), recursive=True) if "__MACOSX" not in e)
    best = None
    for a in exps:
        e = os.path.dirname(a)
        for pn in sorted(os.listdir(os.path.join(e, "pdata"))):
            try:
                ppm, y, pr = B.read_1r(e, int(pn))
            except Exception:
                continue
            if ppm.max() < 1300:            # electrolyte-only narrow spectrum: no metal window
                continue
            ac = B.read_params(a)
            ns = F.noise_sd(ppm, y)
            f = F.fit_metal(ppm, y, ns)
            m0 = (ppm < 60) & (ppm > -60)
            rows.append(dict(archive=os.path.basename(os.path.dirname(e)) if False else e.split(os.sep)[-2] if False else None,
                             experiment=os.path.basename(e), procno=int(pn), processed_by="authors (TopSpin, pdata as published)",
                             line_broadening_Hz=B.num(pr, "LB"), noise_sd=ns, spectrometer_frequency_MHz=B.num(ac, "BF1"),
                             spectral_width_Hz=B.num(ac, "SW_h"), td=int(B.num(ac, "TD")), ns_scans=int(B.num(ac, "NS")),
                             pulse_program=ac.get("PULPROG"), max_0ppm_over_noise=float(y[m0].max() / ns),
                             metal_mu_ppm=f.get("mu_ppm"), metal_u_mu_ppm=f.get("u_mu_ppm"), metal_sigma_ppm=f.get("sigma_ppm"),
                             metal_snr=f.get("snr"), metal_area=f.get("area"), metal_reduced_chi2=f.get("reduced_chi2"), metal_at_bound=f.get("at_bound"),
                             label="MEASURED spectrum, DERIVED fit"))
            if pn == "2" and f.get("snr", 0) > 6 and not f.get("at_bound") and (best is None or f["snr"] > best[3]["snr"]):
                best = (ppm, y, ns, f, os.path.basename(e))
    rf = pd.DataFrame(rows).drop(columns=["archive"])
    rf.to_csv(os.path.join(out, "real_fits.csv"), index=False)
    pd.DataFrame(man).to_csv(os.path.join(out, "source_manifest.csv"), index=False)
    ec = glob.glob(os.path.join(tmp, "*", "**", "Electrochemistry*"), recursive=True)
    ec = [e for e in ec if "__MACOSX" not in e]
    if ec:
        d = np.loadtxt(ec[0])
        summ = {"file": os.path.basename(ec[0]), "columns": ["time_s", "current_A", "voltage_V"], "n_rows": int(len(d)),
                "duration_s": float(d[-1, 0]), "sample_interval_s": float(d[1, 0] - d[0, 0]),
                "current_A_charge_median": float(np.median(d[d[:, 1] > 0, 1])), "current_A_discharge_median": float(np.median(d[d[:, 1] < 0, 1])) if (d[:, 1] < 0).any() else None,
                "voltage_V_min": float(d[:, 2].min()), "voltage_V_max": float(d[:, 2].max()), "voltage_V_last": float(d[-1, 2]),
                "label": "MEASURED (Bray et al.), summary only"}
        json.dump(summ, open(os.path.join(out, "real_electrochemistry_summary.json"), "w"), indent=1)
    if best is not None:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        ppm, y, ns, f, name = best
        fig, ax = plt.subplots(2, 1, figsize=(8, 6), sharex=True, gridspec_kw={"height_ratios": [3, 1]})
        w = (ppm < 1250) & (ppm > 950)
        model = F.gauss_lin(ppm, 0, 0, 0, 0, 1)
        mw = (ppm <= 1200) & (ppm >= 1000)
        p = [None]
        fit = np.full_like(y, np.nan)
        from scipy.optimize import curve_fit
        pp, _ = curve_fit(F.gauss_lin, ppm[mw], y[mw], p0=[0, 0, f["H"], f["mu_ppm"], f["sigma_ppm"]])
        fit[mw] = F.gauss_lin(ppm[mw], *pp)
        ax[0].plot(ppm[w], y[w] / ns, color="0.3", lw=1, label=f"MEASURED: Bray et al., {name} (authors' processing)")
        ax[0].plot(ppm[mw], fit[mw] / ns, color="tab:blue", lw=2, label=f"Gaussian fit: mu = {f['mu_ppm']:.0f} ppm, sigma = {f['sigma_ppm']:.0f} ppm, SNR = {f['snr']:.1f}")
        ax[0].set_ylabel("intensity / noise SD")
        ax[0].legend(fontsize=8)
        ax[1].plot(ppm[mw], (y[mw] - fit[mw]) / ns, color="tab:red", lw=1)
        ax[1].axhline(0, color="0.6", lw=0.8)
        ax[1].set_ylabel("residual / noise")
        ax[1].set_xlabel("23Na chemical shift (ppm)")
        ax[1].set_xlim(1250, 950)
        fig.suptitle("Real metallic-sodium resonance (Bray et al. 2020, Figure 5 data) with the pipeline's Gaussian fit", fontsize=10)
        fig.text(0.01, 0.005, "Source: experimental_reference/real_fits.csv; original data https://edata.bham.ac.uk/456/", fontsize=7, color="0.4")
        fig.tight_layout(rect=(0, 0.02, 1, 0.97))
        fig.savefig(os.path.join(root, "images", "01_real_bray_fit.png"), dpi=130)
    print(rf[["experiment", "procno", "metal_mu_ppm", "metal_sigma_ppm", "metal_snr", "metal_at_bound"]].round(2).to_string())


if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if x.endswith(".zip")]
    r = [x for x in sys.argv[1:] if not x.endswith(".zip")]
    main(a, r[0] if r else os.path.dirname(HERE))
