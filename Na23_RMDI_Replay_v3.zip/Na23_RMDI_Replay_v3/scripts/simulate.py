"""Synthetic 23Na spectrum simulator (time domain), using acquisition parameters taken from the Bray et al.
Figure 5 data (DERIVED) and declared spectral components (ASSUMED unless noted).

Each component is a complex exponential with a decay envelope; its amplitude is set from the requested AREA
(area first, then height follows from the width: H = A / (sigma sqrt(2 pi)) for a Gaussian).
The time-domain amplitude that gives spectral area A (ppm x a.u.) after our processing is c = 2 A / SW_ppm,
because the processing halves the first point and integrates over SW_ppm.
"""
from __future__ import annotations
import numpy as np

# acquisition taken from Figure_5.zip acqus/procs (MEASURED)
ACQ = {"BF1": 105.855213, "SFO1": 105.91308252, "SF": 105.855213, "SW_h": 250000.0, "TD_complex": 256,
       "NS": 32768, "D1_s": 0.05, "PULPROG": "zg_se1.gep", "NUC1": "23Na", "OFFSET_ppm": 1727.544,
       "PROBHD": "25 mm MIC 23Na XYZ-GRD (T121292)"}
SW_PPM = ACQ["SW_h"] / ACQ["SF"]
CENTER_PPM = ACQ["OFFSET_ppm"] - SW_PPM / 2.0


def t_axis(n=ACQ["TD_complex"]):
    return np.arange(n) / ACQ["SW_h"]


def component(area, shift_ppm, gauss_sigma_ppm=0.0, lor_fwhm_ppm=0.0, eta=0.0, phase=0.0):
    """Pseudo-Voigt in time domain: (1-eta) Gaussian + eta Lorentzian, both with spectral area `area`."""
    t = t_axis()
    nu = (shift_ppm - CENTER_PPM) * ACQ["SF"]          # Hz relative to the carrier
    c = 2.0 * area / SW_PPM
    sg = gauss_sigma_ppm * ACQ["SF"]                   # Hz
    wl = lor_fwhm_ppm * ACQ["SF"]
    env_g = np.exp(-2.0 * np.pi ** 2 * sg ** 2 * t ** 2)
    env_l = np.exp(-np.pi * wl * t)
    env = (1.0 - eta) * env_g + eta * env_l if eta > 0 else env_g * (env_l if wl > 0 else 1.0)
    return c * env * np.exp(2j * np.pi * nu * t + 1j * phase)


def spectrum_fid(components, noise_sd_time, rng, sensitivity=1.0, freq_offset_ppm=0.0):
    """components: list of dicts for component(); sensitivity scales signals only (coil loading / gain drift);
    freq_offset_ppm shifts every line (reference frequency error)."""
    fid = np.zeros(ACQ["TD_complex"], complex)
    for c in components:
        c = dict(c)
        c["shift_ppm"] = c["shift_ppm"] + freq_offset_ppm
        fid += sensitivity * component(**c)
    fid += noise_sd_time * (rng.standard_normal(len(fid)) + 1j * rng.standard_normal(len(fid))) / np.sqrt(2)
    return fid
