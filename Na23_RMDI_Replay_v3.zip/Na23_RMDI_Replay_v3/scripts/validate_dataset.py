"""Validator — schema, units, references, timestamps, value ranges, hashes and truth isolation.

python scripts/validate_dataset.py [dataset_root]          -> documentation/validation_report.json (+ exit code 1 on errors)
python scripts/validate_dataset.py --packet file.json       -> validates one packet (used by the regression tests)
"""
from __future__ import annotations
import os, sys, json, glob, hashlib, re
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ALLOWED_UNITS = {"rmdi": {"1", "a.u."}, "eoc_metal_area": {"a.u."}}
KNOWN_PIPELINE_VERSIONS = {"1.0", "1.1"}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def check_packet(p, root, schema=None, expected_version=None):
    """Returns (errors, warnings) for one packet dict."""
    errs, warns = [], []
    if schema is not None:
        import jsonschema
        for e in jsonschema.Draft202012Validator(schema).iter_errors(p):
            errs.append("schema: " + "/".join(map(str, e.absolute_path)) + " " + e.message[:150])
    obs = p.get("observable")
    if obs in ALLOWED_UNITS and p.get("unit") not in ALLOWED_UNITS[obs]:
        errs.append(f"unit '{p.get('unit')}' not allowed for {obs} (allowed {sorted(ALLOWED_UNITS[obs])})")
    src = p.get("source_object")
    if not src:
        errs.append("source_object missing")
    else:
        fp = os.path.join(root, src)
        if not os.path.exists(fp):
            errs.append(f"source_object not found: {src}")
        elif p.get("source_sha256") != sha256(fp):
            errs.append("source_sha256 does not match the source file")
    if p.get("origin") != "SIMULATED":
        errs.append("synthetic evidence must carry origin SIMULATED")
    ver = (p.get("processing") or {}).get("version")
    if ver not in KNOWN_PIPELINE_VERSIONS:
        errs.append(f"unknown processing version {ver}")
    elif expected_version and ver != expected_version:
        warns.append(f"processing version changed: {expected_version} -> {ver} (comparability must be shown)")
    if p.get("value") is None and p.get("detection_class") == "detected" and p.get("qc_status") != "FAIL":
        errs.append("detected and not FAIL but value is null")
    if p.get("value") is not None and p.get("detection_class") != "detected":
        errs.append("value given for a non-detection or uncertain detection (must be null + upper limit / category)")
    if p.get("detection_class") == "not_detected" and p.get("upper_limit") is None and p.get("qc_status") != "FAIL":
        errs.append("non-detection without upper limit")
    worst = max([c["status"] for c in p.get("qc_checks", [])] or ["PASS"], key=lambda s: {"PASS": 0, "WARN": 1, "FAIL": 2}[s])
    if p.get("qc_status") != worst:
        errs.append(f"qc_status {p.get('qc_status')} differs from worst check {worst}")
    if p.get("qc_status") == "FAIL" and (p.get("twin_action") or {}).get("recommended") != "reject":
        errs.append("FAIL packet must recommend reject")
    return errs, warns


def main(root):
    rep = {"errors": [], "warnings": [], "checked": {}}
    E, W = rep["errors"], rep["warnings"]
    schema = json.load(open(os.path.join(root, "schema", "evidence_packet_v1.0.schema.json")))
    # packets
    n = 0
    for f in sorted(glob.glob(os.path.join(root, "evidence_packets", "*", "*.json"))):
        p = json.load(open(f))
        e, w = check_packet(p, root, schema, "1.0")
        E += [f"{os.path.relpath(f, root)}: {x}" for x in e]
        W += [f"{os.path.relpath(f, root)}: {x}" for x in w]
        n += 1
    rep["checked"]["packets"] = n
    # tables: missing values in required columns, ranges, references
    sh = pd.read_csv(os.path.join(root, "digital_twin", "state_history.csv"))
    for col in ("replay", "cycle_n", "state_version", "action", "health_trend", "safety_warning", "recommended_next_measurement", "charging_suggestion_next_cycle"):
        if sh[col].isna().any():
            E.append(f"state_history.csv: missing values in {col}")
    for rp, g in sh.groupby("replay"):
        if not g.state_version.is_monotonic_increasing or not g.cycle_n.is_monotonic_increasing:
            E.append(f"state_history.csv: {rp} not in cycle / version order")
    for c in sh.observation_packet.dropna():
        pass
    fp = pd.read_csv(os.path.join(root, "nmr", "fitted_peaks.csv"))
    for s in fp.source_object:
        if not os.path.exists(os.path.join(root, s)):
            E.append(f"fitted_peaks.csv: broken reference {s}")
    for s in fp.spectrum_csv.dropna():
        if s and not os.path.exists(os.path.join(root, s)):
            E.append(f"fitted_peaks.csv: broken reference {s}")
    bad = fp[(fp.noise_sd <= 0) | (fp.noise_sd > 10)]
    if len(bad):
        E.append(f"fitted_peaks.csv: {len(bad)} implausible noise values")
    idx = pd.read_csv(os.path.join(root, "metadata", "spectra_index.csv"))
    for rp, g in idx[idx.replay.isin(["MAIN", "V1", "V2a", "V2b", "V3"])].groupby("replay"):
        t = pd.to_datetime(g.sort_values(["cycle_n", "stage"]).acquisition_start)
        if not t.is_monotonic_increasing:
            E.append(f"spectra_index.csv: timestamps of {rp} not in order")
    if (idx.cell_temperature_C < -20).any() or (idx.cell_temperature_C > 80).any():
        E.append("spectra_index.csv: implausible temperature")
    # truth isolation: no script except evaluate.py may mention ground_truth
    for f in glob.glob(os.path.join(root, "scripts", "*.py")):
        name = os.path.basename(f)
        if name in ("evaluate.py", "generate_dataset.py", "validate_dataset.py", "make_tests.py"):
            continue
        txt = open(f).read()
        if "ground_truth" in txt.replace("never ground_truth", "").replace("Never reads ground_truth", "").replace("never reads ground_truth", "").replace("never ground_truth/", ""):
            if re.search(r"open\(.*ground_truth|read_csv\(.*ground_truth|join\(root, \"ground_truth\"", txt):
                E.append(f"{name} reads ground_truth/")
    # manifest
    man = os.path.join(root, "dataset_manifest.csv")
    if os.path.exists(man):
        m = pd.read_csv(man)
        for r in m.itertuples():
            p = os.path.join(root, r.path)
            if not os.path.exists(p):
                E.append(f"manifest: missing {r.path}")
            elif sha256(p) != r.sha256:
                E.append(f"manifest: hash mismatch {r.path}")
        rep["checked"]["manifest_files"] = len(m)
    else:
        W.append("dataset_manifest.csv not present yet")
    rep["result"] = "VALID" if not E else "INVALID"
    os.makedirs(os.path.join(root, "documentation"), exist_ok=True)
    json.dump(rep, open(os.path.join(root, "documentation", "validation_report.json"), "w"), indent=1)
    print(f"{rep['result']}: {len(E)} errors, {len(W)} warnings, {n} packets")
    for x in E[:20]:
        print("ERROR", x)
    return 0 if not E else 1


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--packet":
        root = sys.argv[3] if len(sys.argv) > 3 else os.path.dirname(HERE)
        schema = json.load(open(os.path.join(root, "schema", "evidence_packet_v1.0.schema.json")))
        e, w = check_packet(json.load(open(sys.argv[2])), root, schema, "1.0")
        print(json.dumps({"errors": e, "warnings": w}, indent=1))
        sys.exit(1 if e else 0)
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(HERE)))
