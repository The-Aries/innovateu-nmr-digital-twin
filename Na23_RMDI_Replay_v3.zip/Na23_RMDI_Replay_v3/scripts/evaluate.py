"""Step 4 — score the pipeline and the twin against the hidden truth (the ONLY script that reads ground_truth/).

python scripts/evaluate.py [dataset_root]   ->  digital_twin/evaluation.json, digital_twin/evaluation_checks.csv
"""
from __future__ import annotations
import os, sys, json
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))


def main(root):
    gt = pd.read_csv(os.path.join(root, "ground_truth", "hidden_states.csv"))
    fp = pd.read_csv(os.path.join(root, "nmr", "fitted_peaks.csv"))
    sh = pd.read_csv(os.path.join(root, "digital_twin", "state_history.csv"))
    fc = pd.read_csv(os.path.join(root, "digital_twin", "forecasts.csv"))
    cal = json.load(open(os.path.join(root, "config", "detection_calibration.json")))
    m = fp.merge(gt, on=["replay", "cycle_n", "stage", "expno"], suffixes=("", "_true"))
    rec = cal["peak_area_recovery_factor"]
    m["area_cal"] = m.metal_area / rec
    # fit accuracy on clearly detected, valid synthetic peaks of the replays (not calibration sets)
    ok = m[(~m.replay.str.startswith("CAL")) & (m.true_metal_area >= 900) & (m.sensitivity_factor.between(0.9, 1.1)) & (m.frequency_offset_ppm.abs() < 1)]
    err = (ok.area_cal * 1.0 / ok.sensitivity_factor - ok.true_metal_area) / ok.true_metal_area
    zA = (ok.area_cal / ok.sensitivity_factor - ok.true_metal_area) / (ok.metal_u_area / rec)
    # reference
    refok = m[(m.true_reference_area > 0) & (m.ref_snr >= 5) & (m.ref_fwhm_ppm <= 10)]
    zref = (refok.ref_area - refok.true_reference_area) / refok.u_ref_area
    res = {
        "false_positive_rate_CAL0_uncertain_or_detected": cal["false_positive_rate_at_uncertain_cut"],
        "false_positive_rate_CAL0_detected": cal["false_positive_rate_at_detect_cut"],
        "detection_curve": cal["levels"],
        "fit_relative_area_error_after_recovery": {"n": int(len(err)), "mean": float(err.mean()), "sd": float(err.std()), "rmse": float(np.sqrt((err ** 2).mean()))},
        "fit_area_95pct_coverage_noise_only": float(np.mean(np.abs(zA) <= 1.96)),
        "fit_centre_error_ppm": {"mean": float((ok.metal_mu_ppm - ok.true_metal_shift_ppm).mean()), "sd": float((ok.metal_mu_ppm - ok.true_metal_shift_ppm).std())},
        "reference_area_95pct_coverage": float(np.mean(np.abs(zref) <= 1.96)),
        "reference_area_relative_bias": float(((refok.ref_area - refok.true_reference_area) / refok.true_reference_area).mean()),
        "forecasts": {"n_scored": int(fc.within_95.notna().sum()), "within_95": float(fc.within_95.dropna().astype(bool).mean()) if fc.within_95.notna().any() else None},
    }
    # expected twin responses (scenario catalog)
    S = lambda rep, c: sh[(sh.replay == rep) & (sh.cycle_n == c)].iloc[0]
    checks = []

    def chk(name, cond, detail):
        checks.append(dict(check=name, passed=bool(cond), detail=detail))
    for c in (1, 2):
        r = S("MAIN", c)
        chk(f"MAIN c{c}: non-detection stored as upper limit", r.detection == "not_detected" and pd.notna(r.upper_limit) and pd.isna(r.rmdi_current), f"{r.detection}, UL {r.upper_limit}")
    for c in (3, 4):
        r = S("MAIN", c)
        chk(f"MAIN c{c}: EOC metal detected, PD not detected", r.eoc_detection == "detected" and r.detection == "not_detected", f"EOC {r.eoc_detection}, PD {r.detection}")
    chk("MAIN c4: reduce_current after two agreeing cycles", S("MAIN", 4).charging_suggestion_next_cycle == "reduce_current" and S("MAIN", 3).charging_suggestion_next_cycle == "keep_current", "")
    chk("MAIN c5-7: no accumulation warning", all("accumulation" not in S("MAIN", c).safety_warning for c in (5, 6, 7)), "")
    chk("MAIN c7: forecast available after 3 quantitative points", pd.notna(S("MAIN", 7).forecast_next_mean), "")
    r = S("MAIN", 8)
    chk("MAIN c8: uncertain detection, last RMDI kept, improve_snr", r.detection == "uncertain" and abs(r.rmdi_current - S("MAIN", 7).rmdi_current) < 1e-9 and r.recommended_next_measurement == "improve_snr",
        f"{r.detection}, next {r.recommended_next_measurement}")
    chk("MAIN c9-11: accumulation flagged", any(S("MAIN", c).health_trend == "deteriorating" for c in (9, 10, 11)) and "accumulation" in S("MAIN", 11).safety_warning, "")
    r = S("MAIN", 12)
    chk("MAIN c12: calibration failure rejected, calibration check", r.action == "reject" and r.recommended_next_measurement == "check_reference_calibration"
        and abs(r.rmdi_current - S("MAIN", 11).rmdi_current) < 1e-9, f"{r.action}, {r.recommended_next_measurement}")
    first_elev = next((c for c in range(9, 17) if "elevated" in S("MAIN", c).safety_warning), None)
    chk("MAIN c13-16: elevated concern only after several valid accelerated cycles", first_elev is not None and first_elev >= 14, f"first elevated at cycle {first_elev}")
    chk("V1: hidden signal > 0 but non-detection upper limits", all(S("V1", c).detection == "not_detected" and pd.isna(S("V1", c).rmdi_current) for c in (1, 2)), "")
    v2a = sh[sh.replay == "V2a"]
    chk("V2a: normalisation cancels gain drift, no accumulation", not (v2a.health_trend == "deteriorating").any() and not v2a.safety_warning.str.contains("accumulation").any(),
        f"RMDI {v2a.observed_rmdi.round(3).tolist()}")
    v2b = sh[sh.replay == "V2b"]
    chk("V2b: raw area rises, comparability flagged, no accumulation claimed", v2b.observed_rmdi.iloc[-1] > v2b.observed_rmdi.iloc[0] and
        not (v2b.health_trend == "deteriorating").any() and v2b.safety_warning.str.contains("comparability").all(), f"raw {v2b.observed_rmdi.round(0).tolist()}")
    chk("V3: delay 150 min WARN, 240 min FAIL", S("V3", 3).observation_qc == "WARN" and S("V3", 4).observation_qc == "FAIL" and S("V3", 4).action == "reject", "")
    v4 = sh[sh.replay == "V4"]
    chk("V4: quasimetallic background not detected as metal", (v4.eoc_detection == "not_detected").all(), f"{v4.eoc_detection.tolist()}")
    res["scenario_checks_passed"] = int(sum(c["passed"] for c in checks))
    res["scenario_checks_total"] = len(checks)
    pd.DataFrame(checks).to_csv(os.path.join(root, "digital_twin", "evaluation_checks.csv"), index=False)
    json.dump(res, open(os.path.join(root, "digital_twin", "evaluation.json"), "w"), indent=1, default=float)
    print(json.dumps({k: v for k, v in res.items() if k != "detection_curve"}, indent=1, default=float))
    for c in checks:
        print(("PASS " if c["passed"] else "FAIL ") + c["check"], c["detail"])


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(HERE))
