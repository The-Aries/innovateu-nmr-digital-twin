"""Gaussian peak fit with a linear baseline (specification §3.1) and joint fit of the 0 ppm region.

Metal peak:   S(d) = b0 + b1 (d - 1100) + H exp(-(d - mu)^2 / (2 sigma^2))     in the 1000-1200 ppm window
Area:         A = H sigma sqrt(2 pi);  u_A from the full covariance (incl. the H-sigma correlation)
Centre:       u_mu = sqrt(Cov(mu, mu))   (sigma is the width, NOT the centre uncertainty)
0 ppm region: NaCl reference (narrow Lorentzian) + electrolyte (Lorentzian) fitted jointly (team decision 1A)
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import curve_fit

METAL_WINDOW = (1000.0, 1200.0)
REF_WINDOW = (60.0, -60.0)


def gauss_lin(d, b0, b1, H, mu, sig):
    return b0 + b1 * (d - 1100.0) + H * np.exp(-0.5 * ((d - mu) / sig) ** 2)


def fit_metal(ppm, y, noise_sd, sigma_guess=22.0, mu_bounds=(1000.0, 1200.0), sig_bounds=(12.0, 45.0)):
    m = (ppm <= METAL_WINDOW[1]) & (ppm >= METAL_WINDOW[0])
    x, yy = ppm[m], y[m]
    j = int(np.argmax(yy))
    best = None
    for mu0 in (x[j], 1060.0, 1100.0, 1140.0):
        p0 = [np.median(yy), 0.0, max(yy[j] - np.median(yy), noise_sd), float(np.clip(mu0, *mu_bounds)), sigma_guess]
        lo = [-np.inf, -np.inf, -10 * noise_sd, mu_bounds[0], sig_bounds[0]]
        hi = [np.inf, np.inf, np.inf, mu_bounds[1], sig_bounds[1]]
        try:
            p, C = curve_fit(gauss_lin, x, yy, p0=p0, bounds=(lo, hi), sigma=np.full_like(yy, noise_sd), absolute_sigma=True, maxfev=20000)
        except Exception:
            continue
        r = yy - gauss_lin(x, *p)
        chi2 = float(np.sum((r / noise_sd) ** 2) / max(len(x) - 5, 1))
        if best is None or chi2 < best[2]:
            best = (p, C, chi2, r)
    if best is None:
        return {"converged": False}
    p, C, chi2, r = best
    b0, b1, H, mu, sig = p
    s2p = np.sqrt(2 * np.pi)
    A = H * sig * s2p
    g = np.array([0, 0, sig * s2p, 0, H * s2p])
    uA = float(np.sqrt(max(g @ C @ g, 0)))
    at_bound = bool(np.isclose(mu, mu_bounds[0], atol=0.5) or np.isclose(mu, mu_bounds[1], atol=0.5)
                    or np.isclose(sig, sig_bounds[0], rtol=1e-3) or np.isclose(sig, sig_bounds[1], rtol=1e-3))
    return {"converged": bool(np.all(np.isfinite(C))), "H": float(H), "u_H": float(np.sqrt(C[2, 2])), "mu_ppm": float(mu),
            "u_mu_ppm": float(np.sqrt(C[3, 3])), "sigma_ppm": float(abs(sig)), "u_sigma_ppm": float(np.sqrt(C[4, 4])),
            "cov_H_sigma": float(C[2, 4]), "area": float(A), "u_area": uA, "reduced_chi2": chi2,
            "snr": float(H / noise_sd), "at_bound": at_bound, "n_points": int(m.sum()),
            "residual_rms": float(np.sqrt(np.mean(r ** 2)))}


def lor(d, A, x0, w):
    """Area-normalised Lorentzian, FWHM w (ppm)."""
    return A * (w / (2 * np.pi)) / ((d - x0) ** 2 + (w / 2) ** 2)


def ref_model(d, b0, Ar, xr, wr, Ae, xe, we):
    return b0 + lor(d, Ar, xr, wr) + lor(d, Ae, xe, we)


def fit_reference(ppm, y, noise_sd, xr0=0.0, xe0=-8.0):
    m = (ppm <= REF_WINDOW[0]) & (ppm >= REF_WINDOW[1])
    x, yy = ppm[m], y[m]
    tot = np.trapezoid(yy[::-1], x[::-1])
    p0 = [0.0, 0.4 * tot, xr0, 15.0, 0.6 * tot, xe0, 20.0]
    lo = [-np.inf, 0, xr0 - 8, 4, 0, xe0 - 15, 4]
    hi = [np.inf, np.inf, xr0 + 8, 60, np.inf, xe0 + 15, 80]
    try:
        p, C = curve_fit(ref_model, x, yy, p0=p0, bounds=(lo, hi), sigma=np.full_like(yy, noise_sd), absolute_sigma=True, maxfev=40000)
    except Exception:
        return {"converged": False}
    r = yy - ref_model(x, *p)
    return {"converged": True, "ref_area": float(p[1]), "u_ref_area": float(np.sqrt(C[1, 1])), "ref_shift_ppm": float(p[2]),
            "u_ref_shift_ppm": float(np.sqrt(C[2, 2])), "ref_fwhm_ppm": float(p[3]),
            "electrolyte_area": float(p[4]), "electrolyte_shift_ppm": float(p[5]), "electrolyte_fwhm_ppm": float(p[6]),
            "corr_ref_electrolyte": float(C[1, 4] / np.sqrt(C[1, 1] * C[4, 4])) if C[1, 1] > 0 and C[4, 4] > 0 else None,
            "ref_reduced_chi2": float(np.sum((r / noise_sd) ** 2) / max(len(x) - 7, 1))}


def noise_sd(ppm, y, regions=((1700.0, 1350.0), (-350.0, -630.0))):
    m = np.zeros_like(ppm, bool)
    for hi, lo in regions:
        m |= (ppm <= hi) & (ppm >= lo)
    # remove a straight line within each region before taking the SD
    res = []
    for hi, lo in regions:
        k = (ppm <= hi) & (ppm >= lo)
        if k.sum() > 5:
            c = np.polyfit(ppm[k], y[k], 1)
            res.append(y[k] - np.polyval(c, ppm[k]))
    return float(np.std(np.concatenate(res)))


# ---------------------------------------------------------------------------------------------------------------
# Reference + electrolyte: joint fit in the TIME domain (team decision 1A).
# The two lines overlap near 0 ppm and the acquisition is only ~1 ms long, so a frequency-domain fit cannot
# separate them reliably. In the late part of the FID (t >= T_START) the broad components (metal, hard carbon)
# have decayed, so two complex Lorentzians describe the signal; the noise there is white, so the covariance is honest.
T_START_S = 0.30e-3


def fit_reference_td(fid, sw_hz, sf_mhz, offset_ppm, ref0_ppm=0.0, el0_ppm=-10.0):
    from scipy.optimize import least_squares
    n = len(fid)
    t = np.arange(n) / sw_hz
    k = t >= T_START_S
    tt, yy = t[k], fid[k]
    sw_ppm = sw_hz / sf_mhz
    center = offset_ppm - sw_ppm / 2.0
    nu = lambda ppm: (ppm - center) * sf_mhz

    def model(p):
        ar, xr, wr, ae, xe, we = p
        return (ar * np.exp(2j * np.pi * nu(xr) * tt - np.pi * wr * sf_mhz * tt)
                + ae * np.exp(2j * np.pi * nu(xe) * tt - np.pi * we * sf_mhz * tt))

    def res(p):
        r = yy - model(p)
        return np.r_[r.real, r.imag]

    a0 = np.abs(fid[k][0]) * np.exp(np.pi * 15 * sf_mhz * T_START_S)
    p0 = [0.2 * a0, ref0_ppm, 4.0, 0.8 * a0, el0_ppm, 13.0]
    lo = [0, ref0_ppm - 6, 0.5, 0, el0_ppm - 15, 2.0]
    hi = [np.inf, ref0_ppm + 6, 30, np.inf, el0_ppm + 15, 60]
    best = None
    for f in (0.1, 0.25, 0.5):
        p0[0], p0[3] = f * a0, (1 - f) * a0
        try:
            r = least_squares(res, p0, bounds=(lo, hi), max_nfev=4000)
        except Exception:
            continue
        if best is None or r.cost < best.cost:
            best = r
    if best is None:
        return {"converged": False}
    p = best.x
    dof = max(2 * k.sum() - 6, 1)
    s2 = 2 * best.cost / dof
    J = best.jac
    try:
        C = np.linalg.inv(J.T @ J) * s2
    except np.linalg.LinAlgError:
        return {"converged": False}
    to_area = sw_ppm / 2.0              # c = 2 A / SW_ppm  ->  A = c SW_ppm / 2
    noise_time = np.sqrt(s2)
    return {"converged": bool(best.success), "ref_area": float(p[0] * to_area), "u_ref_area": float(np.sqrt(C[0, 0]) * to_area),
            "ref_shift_ppm": float(p[1]), "u_ref_shift_ppm": float(np.sqrt(C[1, 1])), "ref_fwhm_ppm": float(p[2]),
            "electrolyte_area": float(p[3] * to_area), "u_electrolyte_area": float(np.sqrt(C[3, 3]) * to_area),
            "electrolyte_shift_ppm": float(p[4]), "electrolyte_fwhm_ppm": float(p[5]),
            "corr_ref_electrolyte": float(C[0, 3] / np.sqrt(C[0, 0] * C[3, 3])), "ref_fit_noise_time": float(noise_time),
            "ref_snr": float(p[0] / noise_time), "ref_fit_method": f"time-domain, 2 Lorentzians, t >= {T_START_S * 1e3:.2f} ms"}
