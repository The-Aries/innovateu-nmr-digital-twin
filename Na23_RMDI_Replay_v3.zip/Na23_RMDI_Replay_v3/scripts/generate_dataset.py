"""Step 1 — generate every synthetic spectrum, its metadata and the hidden truth.

python scripts/generate_dataset.py [dataset_root]

Writes: config/simulation_config.json, metadata/*.csv, nmr/spectra/<replay>/<expno>/ (Bruker),
ground_truth/hidden_states.csv, ground_truth/scenario_catalog.json.
Fixed seeds: the same command reproduces every file.
"""
from __future__ import annotations
import os, sys, json, datetime as dt
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import simulate as S, nmrproc as N, bruker as B

SEED = 20261121

# ------------------------------------------------------------------------------------------------ configuration
CONFIG = {
    "dataset": "Na23_RMDI_Replay_v3",
    "version": "3.0",
    "seed": SEED,
    "origin": "SIMULATED (spectra, metadata, trajectory); acquisition parameters DERIVED from Bray et al. Figure 5",
    "acquisition": {**S.ACQ, "label": "MEASURED in Figure_5.zip acqus/procs; copied"},
    "noise": {"processed_noise_sd_au": 1.0, "noise_sd_time": 1.0 / 3.0572, "label": "ASSUMED scale: 1 a.u. = processed noise SD at nominal NS"},
    "components": {
        "nacl_reference": {"area": 5000.0, "shift_ppm": 0.0, "lor_fwhm_ppm": 3.0, "label": "ASSUMED (no capillary in the Bray cell)"},
        "electrolyte": {"area": 5500.0, "shift_ppm": -10.0, "lor_fwhm_ppm": 13.0,
                        "label": "area/noise and processed FWHM (~30 ppm) DERIVED from Figure 5 (area/noise 4200-7300); shift ASSUMED (Bray spectra have no absolute reference)"},
        "hard_carbon_post_discharge": {"area": 600.0, "shift_ppm": 80.0, "gauss_sigma_ppm": 60.0, "label": "ASSUMED"},
        "hard_carbon_quasimetallic_end_of_charge": {"area": 2500.0, "shift_ppm": 250.0, "gauss_sigma_ppm": 120.0,
                                                    "label": "ASSUMED (Figure 7 not available; broad quasimetallic contribution after charge)"},
        "metal": {"shift_range_ppm": [1050.0, 1115.0], "intrinsic_gauss_sigma_ppm_range": [16.0, 22.0], "lorentz_fraction_eta": 0.15,
                  "label": "position range from Bray et al. (1050-1115 ppm); processed sigma ~20-30 ppm DERIVED from fits of Figure 5 spectra 63 and 65; eta ASSUMED"},
    },
    "protocol": {"cell_id": "cell-001", "cathode": "NaNFMSO (ASSUMED, pending confirmation)", "anode": "hard carbon (Bray-type, ASSUMED)",
                 "upper_voltage_V": 4.2, "lower_voltage_V": None,
                 "lower_voltage_note": "not specified by the team; not inferred (the Bray electrochemistry file ends at 1.50 V, MEASURED, shown for information only)",
                 "charge_current": "constant, 30 mA/g (rate named in the Bray electrochemistry file)", "nominal_temperature_C": 25.0,
                 "charge_duration_s": 29892, "discharge_duration_s": 29892,
                 "post_discharge_delay_window_min": [10, 60], "nmr_scan_duration_s": round(32768 * (256 / 250000.0 + 0.05)),
                 "start_time": "2026-01-05T08:00:00", "label": "ASSUMED synthetic protocol; durations from the Bray file (MEASURED, about 29,900 s)"},
    "processing_versions": {k: {kk: vv for kk, vv in v.items()} for k, v in N.PROCS.items()},
}

# true post-discharge (pd) and end-of-charge (eoc) metal areas, a.u. (ASSUMED design, chosen against the noise calibration)
MAIN = [  # cycle, pd_area, eoc_area, noise_factor, phase/case
    (1, 0, 0, 1.0, "clean baseline"), (2, 0, 0, 1.0, "clean baseline"),
    (3, 150, 1500, 1.0, "metal at end of charge only"), (4, 150, 1500, 1.0, "metal at end of charge only"),
    (5, 900, 1700, 1.0, "detectable stable residual"), (6, 900, 1700, 1.0, "detectable stable residual"), (7, 900, 1700, 1.0, "detectable stable residual"),
    (8, 900, 1700, 2.5, "ambiguous post-discharge detection (higher noise, valid metadata)"),
    (9, 1450, 2250, 1.0, "credible accumulation"), (10, 2000, 2800, 1.0, "credible accumulation"), (11, 2550, 3350, 1.0, "credible accumulation"),
    (12, 3100, 3900, 1.0, "technically invalid: calibration failure"),
    (13, 4200, 5000, 1.0, "sustained acceleration"), (14, 5300, 6100, 1.0, "sustained acceleration"),
    (15, 6400, 7200, 1.0, "sustained acceleration"), (16, 7500, 8300, 1.0, "sustained acceleration"),
]

EXPECTED = {  # scenario catalog: expected twin behaviour (read only by evaluate.py)
    "MAIN": {1: "initialise; non-detection stored as upper limit", 2: "non-detection upper limit; trend undetermined",
             3: "EOC metal detected; PD non-detection upper limit; current suggestion candidate reduce", 4: "as 3; reduce_current after 2 agreeing cycles",
             5: "first quantitative RMDI", 6: "no accumulation warning", 7: "forecast available; no warning",
             8: "uncertain detection; last accepted RMDI kept; recommend improve_snr", 9: "update", 10: "accumulation flagged",
             11: "accumulation warning; forecast compared", 12: "QC FAIL; reject; recommend check_reference_calibration",
             13: "update", 14: "steeper slope supported", 15: "elevated concern", 16: "elevated concern; expert_review"},
    "V1": {1: "non-detection upper limit although hidden signal > 0", 2: "same"},
    "V2a": {"all": "normalised RMDI flat; no accumulation; reference-area QC WARN/FAIL as gain grows"},
    "V2b": {"all": "raw area rises; comparability flagged; no accumulation claimed"},
    "V3": {3: "delay 150 min -> WARN", 4: "delay 240 min -> FAIL, rejected"},
    "V4": {"all": "broad quasimetallic background, no metal detection"},
}


def acq_for_writer(ns):
    a = S.ACQ
    return {"BF1": a["BF1"], "SFO1": a["SFO1"], "SW_h": a["SW_h"], "SW": round(a["SW_h"] / a["BF1"], 6), "NS": int(ns), "D": "(0..63)",
            "D1": a["D1_s"], "NUC1": a["NUC1"], "PROBHD": a["PROBHD"], "GRPDLY": 0, "DIGMOD": 0,
            "ORIGIN_NOTE": "SIMULATED spectrum; parameters copied from Bray et al. Figure 5 acqus (MEASURED)"}


def components(stage, pd_area, eoc_area, rng, ref_present=True):
    C = CONFIG["components"]
    out = []
    if ref_present:
        out.append(dict(area=C["nacl_reference"]["area"], shift_ppm=0.0, lor_fwhm_ppm=C["nacl_reference"]["lor_fwhm_ppm"]))
    out.append(dict(area=C["electrolyte"]["area"], shift_ppm=C["electrolyte"]["shift_ppm"], lor_fwhm_ppm=C["electrolyte"]["lor_fwhm_ppm"]))
    hc = C["hard_carbon_post_discharge"] if stage == "pd" else C["hard_carbon_quasimetallic_end_of_charge"]
    out.append(dict(area=hc["area"], shift_ppm=hc["shift_ppm"], gauss_sigma_ppm=hc["gauss_sigma_ppm"]))
    area = pd_area if stage == "pd" else eoc_area
    mu = float(rng.uniform(*C["metal"]["shift_range_ppm"]))
    sig = float(rng.uniform(*C["metal"]["intrinsic_gauss_sigma_ppm_range"]))
    if area > 0:
        out.append(dict(area=float(area), shift_ppm=mu, gauss_sigma_ppm=sig, lor_fwhm_ppm=2.3548 * sig, eta=C["metal"]["lorentz_fraction_eta"]))
    return out, mu, sig


def write_one(root, replay, cycle, stage, comps, noise_factor, rng, sensitivity=1.0, freq_offset=0.0, ns=32768, title=""):
    expno = cycle * 10 + (1 if stage == "eoc" else 2) if cycle is not None else None
    fid = S.spectrum_fid(comps, CONFIG["noise"]["noise_sd_time"] * noise_factor, rng, sensitivity, freq_offset)
    acq = dict(SW_h=S.ACQ["SW_h"], SF=S.ACQ["SF"], OFFSET_ppm=S.ACQ["OFFSET_ppm"])
    ppm, y, info = N.process(fid, acq, "1.0", phase=0.0)
    proc = {"SF": S.ACQ["SF"], "OFFSET": round(float(ppm[0]), 6), "SW_p": S.ACQ["SW_h"], "LB": N.PROC_V10["LB_Hz"], "PHC0": 0, "PHC1": 0,
            "AXNUC": "23Na", "WDW": 1, "NOTE": "1r written by the generator for viewing; the pipeline re-processes the fid"}
    d = os.path.join(root, "nmr", "spectra", replay, str(expno))
    B.write_experiment(d, fid, y, acq_for_writer(ns), proc, title=title)
    return d, expno


def main(root):
    rng_master = np.random.default_rng(SEED)
    for sub in ["config", "metadata", "ground_truth", "nmr/spectra"]:
        os.makedirs(os.path.join(root, sub), exist_ok=True)
    P = CONFIG["protocol"]
    t0 = dt.datetime.fromisoformat(P["start_time"])
    cyc_len = P["charge_duration_s"] + P["discharge_duration_s"] + 2 * P["nmr_scan_duration_s"] + 2 * 3600
    spectra, truth, cycles = [], [], []

    def add(replay, cycle, stage, pd_area, eoc_area, noise_factor=1.0, sens=1.0, foff=0.0, temp=25.0, delay=30.0, ref=True, case="", seed=None):
        rng = np.random.default_rng(seed)
        comps, mu, sig = components(stage, pd_area, eoc_area, rng, ref)
        c_idx = cycle if cycle is not None else 0
        t_cyc = t0 + dt.timedelta(seconds=(c_idx - 1) * cyc_len)
        t_eoc_end = t_cyc + dt.timedelta(seconds=P["charge_duration_s"])
        t_dis_end = t_eoc_end + dt.timedelta(seconds=P["nmr_scan_duration_s"] + 1800 + P["discharge_duration_s"])
        acq_start = (t_eoc_end + dt.timedelta(minutes=15)) if stage == "eoc" else (t_dis_end + dt.timedelta(minutes=delay))
        d, expno = write_one(root, replay, cycle, stage, comps, noise_factor, rng, sens, foff, title=f"{replay} cycle {cycle} {stage} SIMULATED")
        rel = os.path.relpath(d, root).replace(os.sep, "/")
        spectra.append(dict(replay=replay, cycle_n=cycle, stage="end_of_charge" if stage == "eoc" else "post_discharge", expno=expno, path=rel,
                            acquisition_start=acq_start.replace(microsecond=0).isoformat(), scan_delay_min=(15.0 if stage == "eoc" else float(delay)),
                            cell_temperature_C=float(temp), number_of_scans=32768, reference_type="NaCl capillary" if ref else "none",
                            origin="SIMULATED"))
        truth.append(dict(replay=replay, cycle_n=cycle, stage=spectra[-1]["stage"], expno=expno, path=rel, seed=seed,
                          true_metal_area=float(pd_area if stage == "pd" else eoc_area), true_metal_shift_ppm=mu, true_metal_sigma_intrinsic_ppm=sig,
                          true_reference_area=CONFIG["components"]["nacl_reference"]["area"] * sens if ref else 0.0,
                          noise_factor=noise_factor, sensitivity_factor=sens, frequency_offset_ppm=foff, case=case))

    def seeds(n):
        return [int(s) for s in rng_master.integers(1, 2 ** 31 - 1, n)]

    # ---- main replay
    s = seeds(2 * len(MAIN))
    for i, (c, pd_a, eoc_a, nf, case) in enumerate(MAIN):
        jit = np.random.default_rng(s[2 * i] + 7)
        temp = 25.0 + float(jit.normal(0, 0.4))
        delay = float(np.clip(jit.normal(30, 8), 15, 55))
        foff = float(jit.normal(0, 0.25))
        sens = float(1 + jit.normal(0, 0.015))
        if c == 12:                                   # documented calibration failure
            foff, sens = 4.2, 0.65
        add("MAIN", c, "eoc", pd_a, eoc_a, 1.0, sens, foff, temp, delay, case=case, seed=s[2 * i])
        add("MAIN", c, "pd", pd_a, eoc_a, nf, sens, foff, temp, delay, case=case, seed=s[2 * i + 1])
        cycles.append(dict(replay="MAIN", cycle_n=c, charge_current="30 mA/g (fixed)", upper_voltage_V=4.2, lower_voltage_V=None,
                           nominal_temperature_C=25.0, cell_temperature_C=round(temp, 2), post_discharge_delay_min=round(delay, 1),
                           system_calibration_status="FAIL: probe detuned, reference frequency off" if c == 12 else "PASS", origin="SIMULATED"))
    # ---- V1 sub-detection
    s = seeds(4)
    for i, c in enumerate([1, 2]):
        add("V1", c, "eoc", 200, 0, case="weak PD peak below the detection limit", seed=s[2 * i])
        add("V1", c, "pd", 200, 0, case="weak PD peak below the detection limit", seed=s[2 * i + 1])
    # ---- V2a / V2b gain drift
    for rep, ref in (("V2a", True), ("V2b", False)):
        s = seeds(12)
        for i, c in enumerate(range(1, 7)):
            g = 1.0 + 0.05 * i
            case = "gain +5 %/acquisition, reference shares it" if ref else "gain +5 %/acquisition, no reference"
            add(rep, c, "eoc", 3000, 3800, 1.0, g, 0.0, ref=ref, case=case, seed=s[2 * i])
            add(rep, c, "pd", 3000, 3800, 1.0, g, 0.0, ref=ref, case=case, seed=s[2 * i + 1])
    # ---- V3 timing mismatch
    s = seeds(8)
    for i, (c, delay) in enumerate([(1, 30), (2, 35), (3, 150), (4, 240)]):
        add("V3", c, "eoc", 900, 1700, delay=delay, case=f"post-discharge delay {delay} min", seed=s[2 * i])
        add("V3", c, "pd", 900, 1700, delay=delay, case=f"post-discharge delay {delay} min", seed=s[2 * i + 1])
    # ---- V4 specificity control: strong broad quasimetallic hump reaching the metal window, no metal
    s = seeds(4)
    for i, c in enumerate(range(1, 5)):
        rng = np.random.default_rng(s[i])
        comps, mu, sig = components("eoc", 0, 0, rng, True)
        comps.append(dict(area=4000.0, shift_ppm=600.0, gauss_sigma_ppm=220.0))
        d, expno = write_one(root, "V4", c, "eoc", comps, 1.0, rng, title="V4 specificity control SIMULATED")
        rel = os.path.relpath(d, root).replace(os.sep, "/")
        spectra.append(dict(replay="V4", cycle_n=c, stage="end_of_charge", expno=expno, path=rel, acquisition_start=(t0 + dt.timedelta(days=c)).isoformat(),
                            scan_delay_min=15.0, cell_temperature_C=25.0, number_of_scans=32768, reference_type="NaCl capillary", origin="SIMULATED"))
        truth.append(dict(replay="V4", cycle_n=c, stage="end_of_charge", expno=expno, path=rel, seed=s[i], true_metal_area=0.0,
                          true_metal_shift_ppm=None, true_metal_sigma_intrinsic_ppm=None, true_reference_area=5000.0, noise_factor=1.0,
                          sensitivity_factor=1.0, frequency_offset_ppm=0.0, case="broad quasimetallic contribution (area 4000 at 600 ppm, sigma 220 ppm), no metal"))
    # ---- calibration sets (post-discharge, background + reference, no or weak metal)
    s = seeds(50 + 90)
    k = 0
    for i in range(50):
        add("CAL0", i + 1, "pd", 0, 0, case="zero metal", seed=s[k]); k += 1
    for lvl in (300, 600, 900):
        for i in range(30):
            add(f"CALW{lvl}", i + 1, "pd", lvl, 0, case=f"weak metal area {lvl}", seed=s[k]); k += 1

    pd.DataFrame(spectra).to_csv(os.path.join(root, "metadata", "spectra_index.csv"), index=False)
    pd.DataFrame(cycles).to_csv(os.path.join(root, "metadata", "cycles.csv"), index=False)
    reps = [dict(replay="MAIN", purpose="16-cycle pitch replay", cycles=16), dict(replay="V1", purpose="sub-detection hidden signal", cycles=2),
            dict(replay="V2a", purpose="gain drift, reference shares gain", cycles=6), dict(replay="V2b", purpose="gain drift, no reference", cycles=6),
            dict(replay="V3", purpose="timing mismatch", cycles=4), dict(replay="V4", purpose="specificity control (quasimetallic, no metal)", cycles=4),
            dict(replay="CAL0", purpose="noise calibration, zero metal", cycles=50),
            dict(replay="CALW300", purpose="noise calibration, weak metal 300 a.u.", cycles=30),
            dict(replay="CALW600", purpose="noise calibration, weak metal 600 a.u.", cycles=30),
            dict(replay="CALW900", purpose="noise calibration, weak metal 900 a.u.", cycles=30)]
    pd.DataFrame(reps).assign(master_seed=SEED).to_csv(os.path.join(root, "metadata", "replays.csv"), index=False)
    pd.DataFrame(truth).to_csv(os.path.join(root, "ground_truth", "hidden_states.csv"), index=False)
    json.dump({"note": "expected twin behaviour per replay and cycle; read only by scripts/evaluate.py", "expected": EXPECTED,
               "main_replay_design": [dict(cycle_n=c, true_pd_area=a, true_eoc_area=e, noise_factor=n, case=k) for c, a, e, n, k in MAIN]},
              open(os.path.join(root, "ground_truth", "scenario_catalog.json"), "w"), indent=1)
    json.dump(CONFIG, open(os.path.join(root, "config", "simulation_config.json"), "w"), indent=1, default=str)
    print(f"generated {len(spectra)} spectra")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(HERE))
