# Scientific assumptions and labels

| Item | Value | Label | Source or reason |
|---|---|---|---|
| Acquisition parameters | 105.855 MHz, 250 kHz, 256 complex points, 32,768 scans, `zg_se1.gep` | MEASURED (copied) | Figure_5.zip acqus |
| Metal peak position range | 1050–1115 ppm | MEASURED range (paper) | Bray et al. 2020: transient full-cell resonance during the first formation charge |
| Metal processed width | σ about 20–25 ppm | DERIVED | Real fits σ 13–31 ppm (`real_fits.csv`) |
| Electrolyte area/noise and width | 5,500 a.u.; processed FWHM about 30 ppm | DERIVED | Real 0 ppm line: area/noise 4,200–7,300; FWHM about 30 ppm |
| Electrolyte shift | −10 ppm | ASSUMED | The Bray spectra have no absolute reference |
| NaCl reference capillary | 5,000 a.u., 0 ppm, 3 ppm FWHM, shares gain with the cell | ASSUMED | No capillary in the Bray cell. Area chosen so the reference is measurable to about 4 % |
| Hard-carbon backgrounds | Broad Gaussians at 80 ppm (post-discharge) and 250 ppm (end of charge); 600 ppm hump in V4 | ASSUMED | Figure 7 not available; the paper reports a broad quasimetallic contribution after charge |
| Cathode / upper voltage | NaNFMSO / 4.2 V | ASSUMED, pending confirmation | Team input. Note: the Bray electrochemistry file reaches 3.60 V maximum (MEASURED), so 4.2 V does not come from that file |
| Lower voltage | Not specified (`null`) | — | Not inferred. The Bray file ends at 1.50 V (information only) |
| Charge/discharge durations | 29,892 s each | DERIVED | Duration of the Bray electrochemistry file |
| Charging current | 30 mA/g, fixed | ASSUMED | Rate named in the Bray file name |
| Temperature, scan delay | 25 °C ± 0.4 K; delay 15–55 min | SIMULATED | Protocol design |
| Residual-metal trajectory | 0 → below detection (150) → flat (900) → +550 per cycle → +1,100 per cycle (a.u.) | ASSUMED | Demo design. Not shown by Bray et al. |
| End-of-charge metal | 1,500 a.u. at cycles 3–4, then post-discharge + 800 | ASSUMED | Demo design |
| Injected faults | Noise × 2.5 (cycle 8); probe detuned × 0.65 + 4.2 ppm (cycle 12); gain +5 %/acquisition (V2); delay 150/240 min (V3) | SIMULATED | Test design |
| QC limits | `config/thresholds.json` | ASSUMED, UNVALIDATED | Team decision 3 |
| Detection cutoffs, upper limit, uncertainty corrections | `config/detection_calibration.json` | DERIVED from the calibration set | Measured with the real fitter |
| Twin conclusions | Trend, warnings, forecasts, suggestions | INFERRED | `digital_twin/` |
