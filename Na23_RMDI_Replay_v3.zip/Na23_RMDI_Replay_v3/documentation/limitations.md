# Limitations

- **RMDI is an NMR signal ratio, not deposited mass.** Skin depth and deposit morphology change how much metallic sodium is NMR-visible. RMDI does not measure thickness, irreversible sodium loss or capacity fade.
- **The real data cover one formation charge of one cell.** Bray et al. support the position and shape of the metallic-sodium resonance, not any accumulation over cycles. The whole trajectory is a demo design.
- **The background is partly assumed.** Figure 7 (post-charge, rested and post-discharge spectra) was not available, so the hard-carbon backgrounds are assumed.
- **The reference is assumed.** The NaCl capillary and its shift relative to the electrolyte are assumptions. With a 1 ms acquisition the two lines can only be separated by a time-domain fit, and the reference term (about 4 %) then dominates the RMDI uncertainty for large deposits.
- **The Gaussian model is biased for these lines.** The Gaussian fit under-reads the area of these lines by about 20 %. This is corrected with a recovery factor measured on the calibration set. The fit also gives χ² WARN on the largest peaks (for example cycle 13), where the line shape deviates most from a Gaussian.
- **QC limits are unvalidated demo values.** Each check's owner still has to confirm them.
- **The thresholds are calibrated on synthetic spectra.** The detection cutoffs and upper limit were measured on 140 synthetic calibration spectra. On real spectra the noise structure can differ, so they must be recalibrated.
- **One simulated cell.** No statement about other cells, designs or populations.
- **No safety control.** The charging suggestion is a research recommendation for the next cycle only. The replay does not act on it, there is no STOP command, and no claim is made that a cell is safe.
- **The 4.2 V upper limit is an assumption.** The NaNFMSO cathode and the 4.2 V upper limit are team assumptions pending confirmation. The real Bray file reaches 3.60 V.
