# Methodology

Pipeline version 1.0 · twin `rmdi_twin 1.0` · seed 20261121 · all spectra SIMULATED

## 1. Real data first

The real Birmingham spectra (Bray et al. 2020, `Figure_5.zip`, `Figure_6.zip`) were read and fitted with the same Gaussian fitter before any synthetic spectrum was designed (`experimental_reference/real_fits.csv`, `images/01_real_bray_fit.png`). Taken from them:

| Quantity | Value | Use |
|---|---|---|
| Acquisition | ²³Na, 105.855 MHz (9.4 T), 250 kHz spectral width, 512 points (256 complex), 32,768 scans, D1 0.05 s, `zg_se1.gep` | Copied into every synthetic `acqus` |
| Processing | Authors used 1800 Hz (procno 2) and 2500 Hz (procno 1) line broadening, 2048 points | Pipeline 1.0 uses 1800 Hz; 1.1 (packet test only) uses 2000 Hz |
| Metal peak | Clearest fit: Na_fullSpectrum_63, μ = 1106 ppm, σ = 31 ppm, SNR 8.4; other spectra σ 13–31 ppm | Synthetic processed σ about 20–25 ppm; position drawn in 1050–1115 ppm |
| 0 ppm line | Processed FWHM about 30 ppm; area / noise 4,200–7,300 | Electrolyte area 5,500 a.u. at noise SD 1 |
| Electrochemistry | Time, current, voltage; about 29,900 s; charge current about 34 µA; voltage 3.60 V maximum, 1.50 V at the end | Charge and discharge durations of the synthetic protocol |

## 2. Spectrum simulation (`scripts/simulate.py`)

Each spectrum is a time-domain signal (256 complex points) made of components plus white complex noise:

| Component | Area (a.u.) | Position | Shape |
|---|---|---|---|
| NaCl reference capillary | 5,000 | 0 ppm | Lorentzian, 3 ppm intrinsic FWHM |
| Electrolyte | 5,500 | −10 ppm | Lorentzian, 13 ppm intrinsic FWHM |
| Hard carbon, post-discharge | 600 | 80 ppm | Gaussian, σ 60 ppm |
| Hard carbon quasimetallic, end of charge | 2,500 | 250 ppm | Gaussian, σ 120 ppm |
| Metallic sodium | from the scenario | 1050–1115 ppm, random per spectrum | Pseudo-Voigt: 85 % Gaussian, 15 % Lorentzian, intrinsic σ 16–22 ppm |

- The area is set first. The time-domain amplitude follows from it as c = 2A / SW_ppm, so changing the width never changes the true area.
- A sensitivity factor scales all signals (gain drift, detuned probe). A frequency offset shifts all lines (reference error).
- The noise is scaled so that the processed noise SD is about 1 a.u. at nominal scans.

## 3. Processing and fitting (`scripts/nmrproc.py`, `scripts/fitting.py`)

1. **Processing.** Exponential line broadening of 1800 Hz, zero filling to 2048 points, FFT, zero-order autophase, then a second-order polynomial baseline fitted on 1700–1350 ppm and −350 to −630 ppm. The noise SD comes from the same regions.
2. **Metal peak.** Gaussian with a linear baseline in 1000–1200 ppm, with σ bounded to 12–45 ppm. A = H·σ·√(2π). u_A comes from the full covariance matrix, including the H–σ correlation. u_μ = √Cov(μ, μ).
3. **Reference and electrolyte (team decision 1A: fitted jointly).** The two lines overlap within 10 ppm, and the acquisition is only 1 ms long, so a frequency-domain fit could not separate them: the reference-area SD was about 50 %. The pipeline therefore fits two complex Lorentzians to the FID from 0.30 ms onwards, where the broad metal and hard-carbon signals have decayed. Result on CAL0: reference-area SD 4.2 %, reference–electrolyte correlation about −0.15, and the reported uncertainty matches the observed scatter (ratio 1.06).
4. **Reference detected.** The reference counts as detected only if its time-domain SNR is at least 5 and its FWHM at most 10 ppm. Otherwise a broad "reference" is just a split of the electrolyte line, as happens in V2b.

## 4. Noise calibration (`scripts/fit_spectra.py`, `config/detection_calibration.json`)

The real fitter was run on 50 spectra without metal (CAL0) and on 3 × 30 spectra with injected areas of 300, 600 and 900 a.u. (CALW).

| Result | Value |
|---|---|
| SNR cut "uncertain" (95th percentile of CAL0, at least 3) | 4.10 |
| SNR cut "detected" (99.5th percentile of CAL0, at least 5) | 7.99 |
| False-positive rate on CAL0 | 6 % uncertain, 2 % detected |
| Detection probability (SNR ≥ 4.1) at 300 / 600 / 900 a.u. | 73 % / 100 % / 100 % |
| Upper limit (95 % detection, interpolated) | 544 a.u. at reference noise, scaled by each spectrum's noise |
| Covariance inflation for metal-fit uncertainties | × 4.16 (processed points are correlated by zero filling and line broadening) |
| Peak-area recovery factor | 0.804 ± 0.019: the Gaussian misses the Lorentzian wings added by line broadening; fitted areas are divided by it |

The preliminary specification cutoffs (SNR 3 and 5) were too permissive for this correlated noise: they would have given more false positives. They were replaced by the measured values, as the specification asks (§3.2).

## 5. QC (`config/thresholds.json`, all limits UNVALIDATED)

There are seven checks per spectrum, each with value, unit, threshold, status and owner (QE = Quantum Engineering, PM = Precision/Metrology, DS = Data Science, DT = Digital Twins):

1. reference shift error (PM)
2. scan delay (PM)
3. cell temperature deviation (PM)
4. reference area / baseline, i.e. sensitivity and comparability (PM)
5. detection limit (QE)
6. fit validity: χ², μ and σ in range, only for fitted peaks (QE)
7. metadata and provenance (DS)

The worst check sets `qc_status`. The detection class (detected / uncertain / not detected) is separate from QC.

## 6. Uncertainty budget

| Contributor | How it is handled | Size |
|---|---|---|
| Spectral noise and fit covariance | Covariance × 4.16 (calibrated) | About 100–140 a.u. on the metal area at noise 1 |
| Peak-model mismatch (Gaussian fit of a pseudo-Voigt after line broadening) | Recovery factor 0.804 ± 0.019 (common to all cycles); plus 4 % per-spectrum systematic | 4 % + 2.4 % |
| Reference area (normalisation) | Time-domain joint fit, uncertainty × 1.06 | 4.2 % |
| Frequency referencing and drift | QC check 1; a failure rejects the spectrum | — |
| RF sensitivity, coil loading | Cancels in the RMDI ratio when the reference shares the gain (V2a); QC check 4 flags it | Up to 25 % on the raw area in V2b |
| Test–retest | From the CALW spread (30 seeds per level) | Equal to the noise term |
| Timing after discharge | QC check 2; outside the window gives WARN or FAIL | — |

The dominant contributor is spectral noise for small deposits and the reference area for large ones. Proposed improvement: a longer acquisition time or a reference capillary at a resolved chemical shift, both of which would shrink the reference term.

Differences between cycles use only the cycle-to-cycle part of the uncertainty. The recovery-factor term is common to all cycles and cancels in differences (specification §4.3, correlated errors).

## 7. Twin rules (`scripts/run_twin.py`)

| Rule | Detail |
|---|---|
| QC gate | PASS → `update`; WARN → `update_with_warning` with uncertainty × √2; FAIL → `reject`, kept in the history, state unchanged |
| Non-detection | Stored as an upper limit RMDI < UL, never as 0 |
| Uncertain detection | No RMDI is created; the last accepted value is kept |
| Health trend | `deteriorating` if Δ > 1.96 u_Δ against the last reliable value, or if the weighted slope over the last 4 points is significantly positive. `stable` (within resolution) or `undetermined` otherwise |
| Warnings | Accumulation warning when the trend is deteriorating. Elevated concern when the slope of the last 3 points exceeds that of the 3 before by more than 1.96 combined SE, for 2 consecutive cycles, and only after accumulation was already established |
| Forecast | Weighted linear trend of the last 4 quantitative points; requires at least 3. 95 % interval. Each forecast is stored before the next observation and scored when it arrives (`forecasts.csv`) |
| Next measurement | `check_reference_calibration`, `repeat_spectrum`, `improve_snr`, `expert_review`, `confirmatory_measurement` or `routine_post_discharge`, with the reason in plain words |
| Charging suggestion (next cycle only) | `reduce_current` after reliable end-of-charge metal or post-discharge accumulation; `insufficient_evidence` if the evidence is rejected, ambiguous or not comparable; `keep_current` otherwise. The output changes only when 2 consecutive cycles agree. The replay itself keeps a fixed current: suggestions are recorded, not applied |
| Without trustworthy normalisation (no reference) | Fallback to calibrated area in a.u. Changes are reported, but no accumulation is claimed |
