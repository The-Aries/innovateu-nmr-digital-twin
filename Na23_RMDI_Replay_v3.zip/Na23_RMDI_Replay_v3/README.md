# Na23_RMDI_Replay_v3 — synthetic ²³Na NMR replay dataset for the RMDI digital twin

One sodium-ion cell (`cell-001`), a 16-cycle replay for the pitch, short variant replays and a noise-calibration set: 212 synthetic ²³Na spectra in Bruker format, their fits, evidence packets (dossier schema v1.0), the rule-based twin's decisions, figures, hidden truth and the scripts that reproduce everything from one seed.

Everything here is SIMULATED except `experimental_reference/real_fits.csv`, which is fitted from the real Birmingham data (Bray et al. 2020). The real data are not redistributed.

## Quick start (Windows or macOS/Linux)

```
pip install -r requirements.txt
python scripts/run_all.py                 # regenerates every file from the seed (about 1 minute)
python -m pytest -q tests                 # 15 regression tests
```

Open `images/04_main_rmdi_trajectory.png` for the whole story in one picture, and `SUMMARY.md` for a one-page overview. The spectra also open in the MRI Data Explorer (Bruker tab): load the folder `nmr/spectra/MAIN`.

## What is in the package

| Folder or file | Content |
|---|---|
| `SUMMARY.md` | One page: what is real, what is simulated, what the twin showed |
| `config/` | `simulation_config.json` (every assumption and the seed), `thresholds.json` (QC limits, UNVALIDATED), `detection_calibration.json` (cutoffs and upper-limit rule measured on the calibration set) |
| `documentation/` | `methodology.md`, `scientific_assumptions.md`, `limitations.md`, `data_dictionary.csv`, `validation_report.json` |
| `experimental_reference/` | `source_manifest.csv` (Figure_5.zip and Figure_6.zip with SHA-256), `real_fits.csv` (Gaussian fits of the real spectra), `real_electrochemistry_summary.json` |
| `metadata/` | `spectra_index.csv` (every spectrum: replay, cycle, stage, timing, temperature), `cycles.csv` (protocol per cycle of the main replay), `replays.csv` |
| `nmr/spectra/<replay>/<expno>/` | Bruker TopSpin folders (`fid`, `acqus`, `pdata/1/1r`, `procs`). `expno` = 10 × cycle + 1 (end of charge) or + 2 (post-discharge); cycle 12 post-discharge = `122` |
| `nmr/spectra_csv/` | The processed spectra as `ppm, intensity_au` (replays only) |
| `nmr/fitted_peaks.csv` | Metal Gaussian fit and reference/electrolyte fit for all 212 spectra |
| `nmr/noise_calibration.csv` | Detection probability and uncertainty calibration from CAL0 and CALW300/600/900 |
| `evidence_packets/<replay>/` | `E-t<cycle>-rmdi.json` (post-discharge) and `E-t<cycle>-eoc_metal_area.json` (end of charge), schema v1.0 |
| `digital_twin/` | `state_history.csv` (every update: prior, evidence, QC gate, action, new state, forecast, warnings, suggestions), `decisions.csv`, `forecasts.csv`, `final_state_<replay>.json`, `evaluation.json`, `evaluation_checks.csv` |
| `images/` | Seven PNG figures, each with its source file in the caption |
| `ground_truth/` | `hidden_states.csv`, `scenario_catalog.json`. Read only by `scripts/evaluate.py` |
| `scripts/` | The pipeline (see below) |
| `tests/` | Regression tests and deliberately broken packets |
| `schema/` | Evidence-packet schema v1.0 (from the dossier StarterPack) |
| `dataset_manifest.csv` | Size and SHA-256 of every file |

## Pipeline (run in this order; `run_all.py` does it)

1. `analyse_real_data.py Figure_5.zip Figure_6.zip` — fits the real spectra (optional; needs the archives from https://edata.bham.ac.uk/456/)
2. `generate_dataset.py` — writes the synthetic spectra, metadata and hidden truth
3. `fit_spectra.py` — processes and fits every spectrum, then sets the detection cutoffs, upper-limit rule and uncertainty corrections from the calibration set
4. `run_twin.py` — QC, packets and the rule-based twin
5. `evaluate.py` — compares with the hidden truth
6. `visualize_dataset.py` — figures
7. `make_tests.py`, `validate_dataset.py` — broken test packets and the full validation

The replays: MAIN (16 cycles, pitch), V1 (signal below the detection limit), V2a/V2b (gain drift with and without reference), V3 (scan timing outside the window), V4 (quasimetallic background without metal), CAL0 and CALW300/600/900 (noise calibration).
