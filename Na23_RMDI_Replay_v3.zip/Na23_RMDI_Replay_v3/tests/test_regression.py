"""Regression tests: the 10 cases of specification §8.2 plus reproducibility and truth isolation.
Run from the dataset root:  python -m pytest -q tests
"""
import os, sys, json, glob, hashlib, subprocess, tempfile, shutil
import pandas as pd
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import validate_dataset as V

SH = pd.read_csv(os.path.join(ROOT, "digital_twin", "state_history.csv"))
SCHEMA = json.load(open(os.path.join(ROOT, "schema", "evidence_packet_v1.0.schema.json")))


def row(rep, c):
    return SH[(SH.replay == rep) & (SH.cycle_n == c)].iloc[0]


def pk(rep, name):
    return json.load(open(os.path.join(ROOT, "evidence_packets", rep, name)))


def test_01_reliable_increase_flags_deterioration():
    assert any(row("MAIN", c).health_trend == "deteriorating" for c in (9, 10, 11))
    assert "accumulation" in row("MAIN", 11).safety_warning


def test_02_change_smaller_than_uncertainty_no_claim():
    for c in (6, 7):
        assert row("MAIN", c).health_trend == "stable"
        assert "accumulation" not in row("MAIN", c).safety_warning
    assert not (SH[SH.replay == "V2a"].health_trend == "deteriorating").any()


def test_03_non_detection_is_upper_limit_not_zero():
    for c in (1, 2):
        p = pk("MAIN", f"E-t{c}-rmdi.json")
        assert p["value"] is None and p["upper_limit"] > 0 and p["detection_class"] == "not_detected"
        assert pd.isna(row("MAIN", c).rmdi_current)
    assert all(pd.isna(row("V1", c).rmdi_current) for c in (1, 2))      # hidden signal > 0, still a limit


def test_04_invalid_measurement_rejected_and_kept():
    r = row("MAIN", 12)
    assert r.action == "reject" and r.observation_qc == "FAIL"
    assert r.rmdi_current == row("MAIN", 11).rmdi_current
    p = pk("MAIN", "E-t12-rmdi.json")
    assert p["twin_action"]["recommended"] == "reject" and os.path.exists(os.path.join(ROOT, p["source_object"]))


def test_05_uncertain_measurement_keeps_ambiguity():
    r = row("MAIN", 8)
    assert r.detection == "uncertain" and r.rmdi_current == row("MAIN", 7).rmdi_current
    p = pk("MAIN", "E-t8-rmdi.json")
    assert p["value"] is None and p["uncertainty"]["type"] == "category"


def test_06_changed_sensitivity_warns_or_flags_comparability():
    v2a = SH[SH.replay == "V2a"]
    assert (v2a.observation_qc != "PASS").any()
    v2b = SH[SH.replay == "V2b"]
    assert v2b.safety_warning.str.contains("comparability").all()
    assert not (v2b.health_trend == "deteriorating").any()


def test_07_changed_processing_version_visible():
    e, w = V.check_packet(json.load(open(os.path.join(ROOT, "tests", "packets", "processing_version_1_1.json"))), ROOT, SCHEMA, "1.0")
    assert any("processing version changed" in x for x in w)


@pytest.mark.parametrize("name,needle", [("wrong_units.json", "unit"), ("missing_source.json", "source_object"), ("wrong_sha256.json", "sha256")])
def test_08_missing_source_or_wrong_units_fail_validation(name, needle):
    e, w = V.check_packet(json.load(open(os.path.join(ROOT, "tests", "packets", name))), ROOT, SCHEMA, "1.0")
    assert e and any(needle in x for x in e)


def test_09_too_few_observations_no_forecast():
    for c in (5, 6):
        assert pd.isna(row("MAIN", c).forecast_next_mean)
    assert pd.notna(row("MAIN", 7).forecast_next_mean)


def test_10_synthetic_origin_everywhere():
    for f in glob.glob(os.path.join(ROOT, "evidence_packets", "*", "*.json")):
        assert json.load(open(f))["origin"] == "SIMULATED"
    e, w = V.check_packet(json.load(open(os.path.join(ROOT, "tests", "packets", "synthetic_labelled_measured.json"))), ROOT, SCHEMA, "1.0")
    assert any("SIMULATED" in x for x in e)


def test_all_real_packets_validate():
    for f in glob.glob(os.path.join(ROOT, "evidence_packets", "*", "*.json")):
        e, w = V.check_packet(json.load(open(f)), ROOT, SCHEMA, "1.0")
        assert not e, (f, e)


def test_twin_never_reads_truth():
    for name in ("fit_spectra.py", "run_twin.py", "visualize_dataset.py"):
        txt = open(os.path.join(ROOT, "scripts", name)).read()
        assert "hidden_states" not in txt and "scenario_catalog" not in txt


def test_generation_is_reproducible():
    tmp = tempfile.mkdtemp()
    try:
        shutil.copytree(os.path.join(ROOT, "scripts"), os.path.join(tmp, "scripts"))
        subprocess.run([sys.executable, os.path.join(tmp, "scripts", "generate_dataset.py"), tmp], check=True, capture_output=True)
        for e in ("MAIN/12", "MAIN/162", "V2a/32"):
            a = hashlib.sha256(open(os.path.join(ROOT, "nmr", "spectra", e, "fid"), "rb").read()).hexdigest()
            b = hashlib.sha256(open(os.path.join(tmp, "nmr", "spectra", e, "fid"), "rb").read()).hexdigest()
            assert a == b
    finally:
        shutil.rmtree(tmp)
