# One-page summary — Na23_RMDI_Replay_v3

**What it is.** One synthetic sodium-ion cell. For each of 16 cycles there is an end-of-charge and a post-discharge ²³Na NMR spectrum. Short variant replays and a 140-spectrum noise calibration test the twin. The twin earns every detection, uncertainty and warning by fitting the spectra and checking their metadata; the hidden truth is used only for scoring.

**What is real.** Acquisition parameters, line widths, noise level and the 1050–1115 ppm metal position come from the Birmingham data (Bray et al. 2020, Figures 5–6; `experimental_reference/`). Everything else is SIMULATED or ASSUMED (`documentation/scientific_assumptions.md`).

**What the twin showed (main replay, `images/04_main_rmdi_trajectory.png`)**

| Cycles | Evidence | Twin response |
|---|---|---|
| 1–2 | Clean baseline | Non-detections stored as upper limits (RMDI < 0.14–0.16), not zero |
| 3–4 | Metal at end of charge only | End-of-charge metal detected; post-discharge still a limit. Current suggestion changes to "reduce" at cycle 4, after two agreeing cycles |
| 5–7 | Stable residual signal | RMDI 0.15–0.23, `stable` within resolution, no warning; forecast available from cycle 7 |
| 8 | Same signal, more noise | Uncertain detection (SNR 6.2): no RMDI created, last value kept; recommend better SNR |
| 9–11 | Credible accumulation | `deteriorating`, accumulation warning. At cycle 11 the measurement lies outside the forecast interval, so the twin recommends a confirmatory measurement |
| 12 | Strong peak but probe detuned (reference area 0.61, shift 4.2 ppm) | QC FAIL, rejected, evidence kept, state unchanged; recommend a calibration check |
| 13–16 | Acceleration | Elevated concern from cycle 14, once several valid cycles support the steeper slope; recommend expert review |

**Variants.**
- V1: a hidden signal below the limit is still reported as a limit.
- V2a: gain drift of +25 % is cancelled by the reference; RMDI stays flat.
- V2b: without a reference the raw area rises, and the twin flags comparability instead of claiming accumulation.
- V3: a scan 150 min after discharge gives WARN; 240 min gives FAIL.
- V4: the broad quasimetallic hump is not mistaken for metal.

**Scores (`digital_twin/evaluation.json`)**

| Measure | Result |
|---|---|
| Scenario checks | 16 of 16 passed |
| False-positive rate (50 spectra without metal) | 6 % uncertain, 2 % detected |
| Detection cutoffs and upper limit | SNR 4.1 / 8.0 and 544 a.u., measured on the calibration set |
| Area error after recovery correction | Mean +0.6 %, SD 8.7 % |
| Reference-area coverage | 97.5 % |
| Forecasts inside their 95 % interval | 9 of 10 |
| Regression tests | 15 passed |
| Validator | VALID |

**Key limitation.** RMDI is a signal ratio, not mass. The real data cover one formation charge, so the accumulation trajectory is a design assumption, and the QC limits are unvalidated. The charging suggestion is a next-cycle research recommendation, not safety control.
